#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "random.h"
#include "metropolis.h"

using namespace std;


/*
// Funzione che restituisce la media dei primi n termini di un vettore
double mean(const vector <double> v, int n) {
	
	if (n == 0) {return 0;}
	else {
		double m = 0.0;
	
		for (int i = 0; i < n; i++) {
			m += v[i];
		}
		m /= n;
		return m;
	}
}


// Funzione che restituisce la deviazione standard della media dei primi n termini di un vettore
double mean_dev_st(const vector<double>& v, int n) {
    if (n <= 0 || n > v.size()) {
        cerr << "Numero di termini non valido!" << endl;
        return 0;
    }
    
    double sum = 0.0;
    double mean = 0.0;

    for (int i = 0; i < n; ++i) {
        sum += v[i];
    }

    mean = sum / n;

    double squared_diff_sum = 0.0;

    // Calcolo la somma dei quadrati delle differenze dalla media
    for (int i = 0; i < n; ++i) {
        double diff = v[i] - mean;
        squared_diff_sum += diff * diff;
    }

    double standard_deviation = sqrt(squared_diff_sum / (n-1));

    return standard_deviation / sqrt(n);
}
*/

 
int main () {

	// Inizializzo il generatore di numeri casuali
	Random rnd;
   
	int seed[4];  // Definisco un vettore 'seed' avente 4 elementi (per ora vuoto)
	int p1, p2;  // Definisco due numeri primi fra loro p1, p2
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Inizializzo l'algoritmo
	
	
	// Oggetto di tipo Statistics
	Statistics st;
	
	// L'algoritmo funziona per u0,s0 = 0.5, delta = 1, T0 = 10, Tf = 0.001
	const int wd = 12;
	ofstream res, des;
	
	// Scelgo le variabili di partenza u_0, s_0 = 0.5 e step massimo di 1.0
	Metropolis metro(1.2, 0.5, 0.5);

    // Valori iniziali di mu e sigma
    double mu = metro.GetMu();
    double sigma = metro.GetSigma();

    // Calcolo dell'energia iniziale
    metro.Run(10000, 0.0);
    double E_old = metro.Energy()[0];
    cout << endl;
    cout << "Initial trial parameters: u = " << metro.GetMu() << "; s = " << metro.GetSigma() << endl;
    cout << "Initial energy: " << metro.Energy()[0] << " +- " << metro.Energy()[1] << endl;
    
    // Verifico che il rate di passi accettati sia del 50% circa
    cout << "Rate accepted steps: " << (double)(metro.GetAccepted()) / (double)(metro.GetAccepted() + metro.GetRejected()) << endl << endl;
    cout << "Proceeding with the Simulated Annealing..." << endl << endl;
    cout << "---------------------------------------------" << endl << endl;
	

    ///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Procedo on il Simulated Annealing
    
    
    // Parametri per l'algoritmo di simulated annealing
    double T0 = 10.0;    // Temperatura iniziale
    double Tf = 0.0001;   // Temperatura finale
    int it = 10;        // Numero di iterazioni per ogni temperatura
    double alpha = 0.9; // Fattore di raffreddamento
    double T = T0;  // Temperatura iniziale
    int iterations = 0;  // Iterazioni totali del calcolo dell'energia mediante algoritmo di Metropolis
    
    // Salvo i dati delle energie campionate (con le incertezze) e dei valori di mu e sigma dopo ogni 10 iterazioni su T fissata
    res.open("output_results.dat");
    // Salvo i dati dell'energia e dei parametri ogni qualvolta si ha un'accettazione del passo del SA
    des.open("output_descend.dat");

    
    // Algoritmo di Simulated Annealing
    while (T > Tf) {
    	// Reset dell'oggetto Metropolis per la prossima iterazione
        // metro.Reset();
    	
        for (int i = 0; i < it; i++) {
        	// Reset dell'oggetto Metropolis per la prossima iterazione
        	metro.Reset();
            // Generazione di nuovi valori per mu e sigma con una piccola perturbazione
            double newMu = mu + rnd.Rannyu(-0.01, 0.01);
            double newSigma = sigma + rnd.Rannyu(-0.01, 0.01);

            // Impostazione dei nuovi valori di mu e sigma nell'oggetto Metropolis
            metro.SetMu(newMu);
            metro.SetSigma(newSigma);

            // Esecuzione di Metropolis per ottenere l'energia con i nuovi valori
            iterations++;
            metro.Run(10000, 0.0);
            double E_new = metro.Energy()[0];

            // Calcolo della differenza di energia
            double deltaE = E_new - E_old;

            // Accettazione o rifiuto dei nuovi valori in base alla differenza di energia e alla temperatura
            if (deltaE <= 0 or rnd.Rannyu() < exp(-deltaE / T)) {
                mu = newMu;
                sigma = newSigma;
                E_old = E_new;
                // Salvo i risultati in 'output_descend.dat'
                des << metro.Energy()[0] << setw(wd) << metro.GetMu() << setw(wd) << metro.GetSigma() << endl;
            }
            // Salvo i risultati in 'output_results.dat'
            // res << iterations  << setw(wd) << metro.Energy()[0] << setw(wd) << metro.Energy()[1] << setw(wd) << metro.GetMu() << setw(wd) << metro.GetSigma() << endl;
        }
        // Salvo i risultati in 'output_results.dat'
        res << iterations  << setw(wd) << metro.Energy()[0] << setw(wd) << metro.Energy()[1] << setw(wd) << metro.GetMu() << setw(wd) << metro.GetSigma() << endl;
        // Riduzione della temperatura
        T *= alpha;
    }
	res.close();
	des.close();
	
    // Salvataggio dei valori finali di mu e sigma finali
    metro.SetMu(mu);
    metro.SetSigma(sigma);
    double finalMu = metro.GetMu();
    double finalSigma = metro.GetSigma();

    // Stampo i risultati
    cout << "Final results" << endl;
    cout << "Final energy: " << metro.Energy()[0] << " +- " << metro.Energy()[1] << endl;
    cout << "Final trial parameters: u = " << finalMu << "; s = " << finalSigma << endl << endl;
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Eseguo il Data Blocking per l'energia con i parametri di trial trovati
	
	
	// Definisco il nuovo oggetto Metropolis
	Metropolis metro1(1.2, finalMu, finalSigma);
	// eseguo 100000 step dell'algoritmo di Metropolis
	// metro1.Run(100000, 0.0);
	
	int M = 1000000;  // Step totali
	int L = 10000;  // Variabili aleatorie estratte per blocco che calcolano l'energia
	int N = M/L;  // Numero di blocchi
	
	vector <double> energies(N);  // Vettore contenente le stime degll'energia
	vector <double> energies_2(N);
	vector <double> sum_prog(N);
	vector <double> sum_prog2(N);
	vector <double> error(N);
	
	
	// Calcolo la media a blocchi dell'energia, mediante il calcolo dell'integrale dell'energia sulle x estrapolate dall'algoritmo di Metropolis
	for (int i = 0; i < N; i++) {
		// eseguo 100000 step dell'algoritmo di Metropolis
		metro1.Run(L, 0.0);
		// Valuto l'energia per questi L step dello i-esimo blocco, e la salvo in 'energies[i]'
		energies[i] = metro1.Energy()[0];
		energies_2[i] = pow(energies[i], 2);
		metro1.Reset();
	}
	
	// Valuto la media progressiva e la deviaziona standard progressiva dell'energia
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog[i] += energies[j];
			sum_prog2[i] += energies_2[j];
		}
		sum_prog[i] /= (i+1);
		sum_prog2[i] /= (i+1);
		error[i] = st.dev_st(sum_prog, sum_prog2, i);
	}
	
	
	// Salvo i valori ottenuti della media e dev. standard progressive in 'output_db.dat'
	ofstream db;
	db.open("output_db.dat");
	
	for (int i = 0; i < N; i++) {
		db << i+1 << setw(wd) << sum_prog[i] << setw(wd) << error[i] << endl;
	}
	db.close();
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Costruisco la densità di probabilità con i parametri di trial trovati
	
	
	// Implemento l'algoritmo di Metropolis coi parametri di trial trovati
	Metropolis metro2(1.2, finalMu, finalSigma);
	int steps = 1000000;
	metro2.Run(steps, 0.0);
	
	// Salvo le variabili estratte in 'distribution.dat'
	ofstream dis;
	dis.open("distribution.dat");
	
	for (int i = 0; i < steps; i++) {
		dis << metro2.GetX()[i] << endl;
	}
	dis.close();
	
	
	///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	rnd.SaveSeed();
	return 0;
}