#include <vector>
#include <cmath>
using namespace std;



class Statistics {

public:

// Funzione per calcolare la deviazione standard progressiva quando si fa la media a blocchi
double dev_st(const vector <double> v1, const vector <double> v2, int n) {
	
	if (n == 0) {
		return 0;
	}
	else {
		return sqrt((v2[n] - pow(v1[n], 2)) / n);
	}
}


// Funzione che restituisce la media dei primi n termini di un vettore
double mean(const vector <double> v, int n) {
	
	if (n == 0) {return 0;}
	else {
		double m = 0.0;
	
		for (int i = 0; i < n; i++) {
			m += v[i];
		}
		m /= n;
		return m;
	}
}


// Funzione che restituisce la deviazione standard della media dei primi n termini di un vettore
double mean_dev_st(const vector<double>& v, int n) {
    if (n <= 0 || n > v.size()) {
        cerr << "Numero di termini non valido!" << endl;
        return 0;
    }
    
    double sum = 0.0;
    double mean = 0.0;

    for (int i = 0; i < n; ++i) {
        sum += v[i];
    }

    mean = sum / n;

    double squared_diff_sum = 0.0;

    // Calcolo la somma dei quadrati delle differenze dalla media
    for (int i = 0; i < n; ++i) {
        double diff = v[i] - mean;
        squared_diff_sum += diff * diff;
    }

    double standard_deviation = sqrt(squared_diff_sum / (n-1));

    return standard_deviation / sqrt(n);
}
	
};