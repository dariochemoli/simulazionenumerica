#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "metropolis.h"


Metropolis::Metropolis(double delta, double u, double s) {
	stepSize = delta;
	numAccepted = 0;
	numRejected = 0;
	mu = u;
	sigma = s;
	
	// Inizializzo il generatore di numeri casuali per l'oggetto "random"
	int seed[4];
	int p1, p2;
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	random.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
}


void Metropolis::Run(int iterations, double x_0) {
	
	for (int i = 0; i < iterations; i++) {
		// Genero un nuovo punto attraverso lo step dell'algoritmo
		double x = x_0;
		x += random.Rannyu(-stepSize, stepSize);
		
		// Calcolo la probabilità di accettazione
		double alpha = Pdf(x) / Pdf(x_0);
		double q = random.Rannyu();
		
		if (alpha >= 1 or q < alpha) {
			x_0 = x;
			numAccepted++;
		}
		else {numRejected++;}
		
		// Salvo il nuovo punto
		X.push_back(x_0);
	}
}


double Metropolis::Pdf(double x) {
	double term1 = exp(-(x - mu) * (x - mu) / (2.0 * sigma * sigma));
    double term2 = exp(-(x + mu) * (x + mu) / (2.0 * sigma * sigma));
    return pow(term1 + term2, 2);
}


/*
vector <double> Metropolis::Energy() {
	// Vettore in cui salvo la media dell'energia con la sua deviazione standard
	vector <double> E;
	
	int M = X.size();
	int L = 100;
	int N = M/L;  // Numero di blocchi
	
	vector <double> energies(N);  // Vettore contenente le stime degll'energia
	vector <double> energies_2(N);
	vector <double> sum_prog(N);
	vector <double> sum_prog2(N);
	vector <double> error(N);
	
	// Calcolo la media a blocchi dell'energia, mediante il calcolo dell'integrale dell'energia sulle x estrapolate dall'algoritmo di Metropolis
	for (int i = 0; i < N; i++) {
		double ene = 0;
		
		for (int j = 0; j < L; j++) {
			double x = X[i*L + j];
			ene += -1/(2*pow(sigma, 4)) * (x*x + mu*mu - sigma*sigma -2*x*mu*tanh(x*mu/(sigma*sigma))) + pow(x, 4) - 5.0/2.0 * x*x; // Stima dell'energia j-esima
		}
		energies[i] = ene/L;  // Media delle energie dello i-esimo blocco
		energies_2[i] = pow(energies[i], 2);
	}
	
	// Valuto la media progressiva e la deviaziona standard progressiva dell'energia
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog[i] += energies[j];
			sum_prog2[i] += energies_2[j];
		}
		sum_prog[i] /= (i+1);
		sum_prog2[i] /= (i+1);
		error[i] = dev_st(sum_prog, sum_prog2, i);
	}
	E.push_back(sum_prog[N-1]);
	E.push_back(error[N-1]);
	return E;
}
*/


vector <double> Metropolis::Energy() {
	vector <double> E;
	vector <double> stats_E;
	int N = X.size();
	
	for (int i = 0; i < N; i++) {
		double x = X[i];
		double ene = -1/(2*pow(sigma, 4)) * (x*x + mu*mu - sigma*sigma -2*x*mu*tanh(x*mu/(sigma*sigma))) + pow(x, 4) - 5.0/2.0 * x*x;
		E.push_back(ene);
	}
	stats_E.push_back(stats.mean(E, N));
	stats_E.push_back(stats.mean_dev_st(E, N));
	
	return stats_E;
}


vector<double> Metropolis::GetX() {
    return X;
}


int Metropolis::GetAccepted() {
    return numAccepted;
}


int Metropolis::GetRejected() {
    return numRejected;
}


void Metropolis::SetMu(double newMu) {
	mu = newMu;
}

	
void Metropolis::SetSigma(double newSigma) {
	sigma = newSigma;
}


double Metropolis::GetMu() {
	return mu;
}


double Metropolis::GetSigma() {
	return sigma;
}


void Metropolis::Reset() {
    X.clear();
    numAccepted = 0;
    numRejected = 0;
}


/*
// Funzione per calcolare la deviazione standard progressiva quando si fa la media a blocchi
double Metropolis::dev_st(const vector <double> v1, const vector <double> v2, int n) {
	
	if (n == 0) {
		return 0;
	}
	else {
		return sqrt((v2[n] - pow(v1[n], 2)) / n);
	}
}


// Funzione che restituisce la media dei primi n termini di un vettore
double mean(const vector <double> v, int n) {
	
	if (n == 0) {return 0;}
	else {
		double m = 0.0;
	
		for (int i = 0; i < n; i++) {
			m += v[i];
		}
		m /= n;
		return m;
	}
}


// Funzione che restituisce la deviazione standard della media dei primi n termini di un vettore
double mean_dev_st(const vector<double>& v, int n) {
    if (n <= 0 || n > v.size()) {
        cerr << "Numero di termini non valido!" << endl;
        return 0;
    }
    
    double sum = 0.0;
    double mean = 0.0;

    for (int i = 0; i < n; ++i) {
        sum += v[i];
    }

    mean = sum / n;

    double squared_diff_sum = 0.0;

    // Calcolo la somma dei quadrati delle differenze dalla media
    for (int i = 0; i < n; ++i) {
        double diff = v[i] - mean;
        squared_diff_sum += diff * diff;
    }

    double standard_deviation = sqrt(squared_diff_sum / (n-1));

    return standard_deviation / sqrt(n);
}
*/