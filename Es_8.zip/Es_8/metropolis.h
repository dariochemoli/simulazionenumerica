#ifndef __Metropolis__
#define __Metropolis__
#include <vector>
#include "random.h"
#include "statistics.cpp"
using namespace std;



class Metropolis {

private:
	// Vettore in cui salvo i valori estratti dall'algoritmo
	vector <double> X;
	
	// Step utilizzato per far evolvere l'algoritmo
	double stepSize;
	
	// Numero di valori accettati e rifiutati dall'algoritmo
	int numAccepted;
	int numRejected;
	
	// Oggetto Random per generare numeri casuali
	Random random;
	
	// Parametri per la funzione d'onda trial
	double mu;
	double sigma;
	
	// Oggetto Statistics per untilizzare le funzioni statistiche
	Statistics stats;
	

public:
	// Costruttore a cui assegno il passo dell'algoritmo, e i parametri di trial u,s
	Metropolis(double delta, double u, double s);
	
	// Implementazione di iterations passi dell'algoritmo utilizzando la distribuzione Pdf a partire dal punto x_0
	void Run(int iterations, double x_0);
	
	// Densità di probabilità tridimensionale in esame (in questo caso è |psi_T|^2)
	double Pdf(double x);
	
	// Metodo che calcola l'energia del sistema per psi(u_o, s_0)
	vector <double> Energy();
	
	// Metodi per accedere alle coordinate estratte dall'algoritmo
	vector <double> GetX();
	
	// Metodi per accedere al numero dei valori accettati e rifiutati
	int GetAccepted();
	int GetRejected();
	
	// Metodi per impostare i parametri privati mu e sigma
	void SetMu(double newMu);
	void SetSigma(double newSigma);
	
	// Metodi per accedere ai parametri della funzione d'onda trial
	double GetMu();
	double GetSigma();
	
	// Metodo per resettare il vettore dei valori estratti
	void Reset();
	
	// double dev_st(const vector <double> v1, const vector <double> v2, int n);
	
};



#endif //__Metropolis