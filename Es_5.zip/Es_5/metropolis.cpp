#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "metropolis.h"


Metropolis::Metropolis(double delta, int I) {
	stepSize = delta;  // Imposto il valore dello step dell'algoritmo
	numAccepted = 0;  // Imposto il numero di valori accettati e rifiutati a 0
	numRejected = 0;
	
	indexPdf = I;  // Scelgo la pdf da utilizzare
	
	// Inizializzo il generatore di numeri casuali per l'oggetto "random"
	int seed[4];
	int p1, p2;
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	random.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
}


void Metropolis::Run(int iterations, vector <double>& position) {
	
	for (int i = 0; i < iterations; i++) {
		// Genero un nuovo punto attraverso lo step dell'algoritmo
		vector<double> newPosition = position;
		newPosition[0] += random.Rannyu(-stepSize, stepSize);
		newPosition[1] += random.Rannyu(-stepSize, stepSize);
		newPosition[2] += random.Rannyu(-stepSize, stepSize);
		
		// Calcolo la probabilità di accettazione
		double alpha = Pdf(newPosition[0], newPosition[1], newPosition[2]) / Pdf(position[0], position[1], position[2]);
		double q = random.Rannyu();
		
		if (alpha >= 1 or q < alpha) {
			position = newPosition;
			numAccepted++;
		}
		else {numRejected++;}
		
		// Salvo le nuove coordinate in X, Y, Z
		// values.push_back(sqrt(position[0]*position[0] + position[1]*position[1] + position[2]*position[2]));
		X.push_back(position[0]);
		Y.push_back(position[1]);
		Z.push_back(position[2]);
	}
}


void Metropolis::RunGaussian(int iterations, vector<double>& position, double dev) {

    for (int i = 0; i < iterations; i++) {
        // Genera un nuovo punto proposto con passo gaussiano
        vector<double> newPosition = position;
        newPosition[0] += random.Gauss(0.0, dev);
        newPosition[1] += random.Gauss(0.0, dev);
        newPosition[2] += random.Gauss(0.0, dev);

       // Calcolo la probabilità di accettazione
		double alpha = Pdf(newPosition[0], newPosition[1], newPosition[2]) / Pdf(position[0], position[1], position[2]);
		double q = random.Rannyu();
		
		if (alpha >= 1 or q < alpha) {
			position = newPosition;
			numAccepted++;
		}
		else {numRejected++;}
		
		// Salvo le nuove coordinate in X, Y, Z
		// values.push_back(sqrt(position[0]*position[0] + position[1]*position[1] + position[2]*position[2]));
		X.push_back(position[0]);
		Y.push_back(position[1]);
		Z.push_back(position[2]);
	}
}



double Metropolis::Pdf(double x, double y, double z) {
	
	// Se indexPdf = 0, allora scelgo la funzione d'onda del primo stato fondamentale
	if (indexPdf == 0) {
		double x_2 = pow(x, 2);
		double y_2 = pow(y, 2);
		double z_2 = pow(z, 2);
		double R = sqrt(x_2 + y_2 + z_2);
		// double a_0 = 0.0529;
	
		return pow(sqrt(pow(a_0, -3) / M_PI) * exp(-R / a_0), 2);
	}
	// Se indexPdf = 1, allora scelgo la funzione d'onda del primo stato eccitato
	else {
		double x_2 = pow(x, 2);
		double y_2 = pow(y, 2);
		double z_2 = pow(z, 2);
		double R = sqrt(x_2 + y_2 + z_2);
		// double a_0 = 0.0529;
	
		return pow(sqrt(pow(a_0, -5) / 32.0*M_PI) * z * exp(-R / (2*a_0)), 2);
	}
}


vector<double> Metropolis::GetX() {
    return X;
}


vector<double> Metropolis::GetY() {
    return Y;
}


vector<double> Metropolis::GetZ() {
    return Z;
}


int Metropolis::GetAccepted() {
    return numAccepted;
}


int Metropolis::GetRejected() {
    return numRejected;
}