#ifndef __Metropolis__
#define __Metropolis__
#include <vector>
#include "random.h"
using namespace std;

// Raggio di Bohr [nm]
const double a_0 = 0.0529;
	

class Metropolis {

private:
	// Vettore in cui salvo i valori delle coordinate estratte dall'algoritmo
	vector <double> X;
	vector <double> Y;
	vector <double> Z;
	
	// Step utilizzato per far evolvere l'algoritmo
	double stepSize;
	
	// Numero di valori accettati e rifiutati dall'algoritmo
	int numAccepted;
	int numRejected;
	
	// Indice che determina quale densità di probabilità utilizzare
	int indexPdf;
	
	// Oggetto Random per generare numeri casuali
	Random random;
	

public:
	// Costruttore
	Metropolis(double delta, int I);
	
	// Implementazioni dell'algoritmo a partire dal punto position
	void Run(int iterations, vector <double>& position);
	
	// Metodo per eseguire l'algoritmo di Metropolis con passo gaussiano
    void RunGaussian(int iterations, vector<double>& position, double dev);
	
	// Densità di probabilità tridimensionale in esame
	double Pdf(double x, double y, double z);
	
	// Metodi per accedere alle coordinate estratte dall'algoritmo
	vector <double> GetX();
	vector <double> GetY();
	vector <double> GetZ();
	
	// Metodi per accedere al numero dei valori accettati e rifiutati
	int GetAccepted();
	int GetRejected();
	
};



#endif //__Metropolis