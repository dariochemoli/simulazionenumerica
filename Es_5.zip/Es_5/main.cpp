#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "random.h"
#include "metropolis.h"

using namespace std;


double dev_st(const vector <double> v1, const vector <double> v2, int n) {
	
	if (n == 0) {
		return 0;
	}
	else {
		return sqrt((v2[n] - pow(v1[n], 2)) / n);
	}
}


double dist(const vector<double> v) {
	double sum = 0.0;
	for (int i = 0; i < v.size(); i++) {
		sum += pow(v[i], 2);
	}
	return sqrt(sum);
}

 
int main (/*int argc, char *argv[]*/) {

	// Inizializzo il generatore di numeri casuali
	Random rnd;
   
	int seed[4];  // Definisco un vettore 'seed' avente 4 elementi (per ora vuoto)
	int p1, p2;  // Definisco due numeri primi fra loro p1, p2
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	// Parametri utili
	int M = 1000000;  // Passi dell'algoritmo di Metropolis
	int L = 10000;  // Campionamenti per ogni blocco
	int N = M/L;  // Numero di blocchi
	vector <double> ave_r(N);
	vector <double> ave_r2(N);
	vector <double> sum_prog_r(N);
	vector <double> sum_prog_r2(N);
	vector <double> error(N);
	
	
	// Oggetto di tipo Metropolis per lo stato fondamentale
	Metropolis metro(1.2*a_0, 0);
	
	// Definisco il punto di partenza dell'algoritmo
	double x_0 = 2*a_0 / sqrt(3);
	double y_0 = 2*a_0 / sqrt(3);
	double z_0 = 2*a_0 / sqrt(3);
	vector<double> r_0 = {x_0, y_0, z_0};
	
	// Produco M step dell'algoritmo di Metropolis a partire da r_0
	metro.Run(M, r_0);
	vector <double> x = metro.GetX();
	vector <double> y = metro.GetY();
	vector <double> z = metro.GetZ();
	vector <double> r(M);  // Vettore delle distanze calcolate dalle coordinate estratte
	
	for (int i = 0; i < M; i++) {
		r[i] = sqrt(x[i]*x[i] + y[i]*y[i] + z[i]*z[i]);
	}
	
	
	// Salvo i valori delle coordinate prodotte dall'algoritmo nel ground state in "results_xyz_gs.dat"
	ofstream myfile;
	myfile.open("results_xyz_gs.dat");
	
	for (int i = 0; i < M; i++) {
        myfile << x[i] << "\t" << y[i] << "\t" << z[i] << endl;
    }
    myfile.close();
	

	// Effettuo l'analisi della posizione dell'elettrone attraverso il Data Blocking
	for (int i = 0; i < N; i++) {
		double sum = 0.0;
		
		// Valuto la media delle distanze per lo i-esimo blocco
		for (int j = 0; j < L; j++) {
			int k = j+i*L;
			sum += r[k];
		}
		ave_r[i] = sum/L;
		ave_r2[i] = pow(ave_r[i], 2);
	}
	
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_r[i] += ave_r[j];
			sum_prog_r2[i] += ave_r2[j];
		}
		sum_prog_r[i] /= (i+1);
		sum_prog_r2[i] /= (i+1);
		error[i] = dev_st(sum_prog_r, sum_prog_r2, i);
	}
	
	
	// Salvo i risultati del Data Blocking in "results_db_gs_u.dat" (DataBlocking_GroundState_Uniform)
	myfile.open("results_db_gs_u.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << i+1 << "\t" << sum_prog_r[i] << "\t" << error[i] << endl;
    }
    myfile.close();
    
    
    // Stampo questo a schermo per verificare che il programma sia andato a buon fine
    cout << endl;
    cout << "GROUND STATE (n = 1, l = 0, m = 0)" << endl;
    cout << "Metropolis algorithm implemented by an uniform distribution" << endl;
	cout << "Accepted steps: " << metro.GetAccepted() << endl;
	cout << "Rejected steps: " << metro.GetRejected() << endl;
	cout << "Ratio between accepted and rejected steps: " << (double)(metro.GetAccepted()) / (double)(M) << endl << endl;
	cout << "------------------------------------------" << endl << endl;
	
	
	// Resetto i vettori definiti precedentemente
	r.assign(M, 0.0);
    ave_r.assign(N, 0.0);
    ave_r2.assign(N, 0.0);
    sum_prog_r.assign(N, 0.0);
    sum_prog_r2.assign(N, 0.0);
    error.assign(N, 0.0);
    
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Eseguo lo stesso procedimento per l'algoritmo implementato da distribuzione gaussiana (ground state)
    
    
    // Oggetto di tipo Metropolis per lo stato fondamentale
	Metropolis metroG(1.2*a_0, 0);

	
	// Produco M step dell'algoritmo di Metropolis a partire da r_0
	metroG.RunGaussian(M, r_0, 0.76*a_0);
	vector <double> xG = metroG.GetX();
	vector <double> yG = metroG.GetY();
	vector <double> zG = metroG.GetZ();
	
	for (int i = 0; i < M; i++) {
		r[i] = sqrt(xG[i]*xG[i] + yG[i]*yG[i] + zG[i]*zG[i]);
	}
	

	// Effettuo l'analisi della posizione dell'elettrone attraverso il Data Blocking
	for (int i = 0; i < N; i++) {
		double sum = 0.0;
		
		// Valuto la media delle distanze per lo i-esimo blocco
		for (int j = 0; j < L; j++) {
			int k = j+i*L;
			sum += r[k];
		}
		ave_r[i] = sum/L;
		ave_r2[i] = pow(ave_r[i], 2);
	}
	
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_r[i] += ave_r[j];
			sum_prog_r2[i] += ave_r2[j];
		}
		sum_prog_r[i] /= (i+1);
		sum_prog_r2[i] /= (i+1);
		error[i] = dev_st(sum_prog_r, sum_prog_r2, i);
	}
	
	
	// Salvo i risultati del Data Blocking in "results_db_gs_g.dat" (DataBlocking_GroundState_Gaussian)
	myfile.open("results_db_gs_g.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << i+1 << "\t" << sum_prog_r[i] << "\t" << error[i] << endl;
    }
    myfile.close();
    
    
    // Stampo questo a schermo per verificare che il programma sia andato a buon fine
    cout << "GROUND STATE (n = 1, l = 0, m = 0)" << endl;
    cout << "Metropolis algorithm implemented by a gaussian distribution" << endl;
	cout << "Accepted steps: " << metroG.GetAccepted() << endl;
	cout << "Rejected steps: " << metroG.GetRejected() << endl;
	cout << "Ratio between accepted and rejected steps: " << (double)(metroG.GetAccepted()) / (double)(M) << endl << endl;
	cout << "------------------------------------------" << endl << endl;
	
	
	// Resetto i vettori definiti precedentemente
	r.assign(M, 0.0);
    ave_r.assign(N, 0.0);
    ave_r2.assign(N, 0.0);
    sum_prog_r.assign(N, 0.0);
    sum_prog_r2.assign(N, 0.0);
    error.assign(N, 0.0);
    
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Eseguo lo stesso procedimento per lo stato eccitato
	
	
	// Oggetto di tipo Metropolis per lo stato eccitato
	Metropolis metro1(3*a_0, 1);
	
	
	// Definisco il punto di partenza dell'algoritmo
	x_0 = 3*a_0 / sqrt(3);
	y_0 = 3*a_0 / sqrt(3);
	z_0 = 3*a_0 / sqrt(3);
	r_0 = {x_0, y_0, z_0};
	
	
	// Produco M step dell'algoritmo di Metropolis a partire da r_0
	metro1.Run(M, r_0);
	vector <double> x1 = metro1.GetX();
	vector <double> y1 = metro1.GetY();
	vector <double> z1 = metro1.GetZ();
	
	for (int i = 0; i < M; i++) {
		r[i] = sqrt(x1[i]*x1[i] + y1[i]*y1[i] + z1[i]*z1[i]);
	}
	
	
	// Salvo i valori delle coordinate prodotte dall'algoritmo nello stato eccitato in "results_xyz_es.dat"
	myfile.open("results_xyz_es.dat");
	
	for (int i = 0; i < M; i++) {
        myfile << x1[i] << "\t" << y1[i] << "\t" << z1[i] << endl;
    }
    myfile.close();
    
    
    // Effettuo l'analisi della posizione dell'elettrone nello stato eccitato attraverso il Data Blocking
	for (int i = 0; i < N; i++) {
		double sum = 0.0;
		
		// Valuto la media delle distanze per lo i-esimo blocco
		for (int j = 0; j < L; j++) {
			int k = j+i*L;
			sum += r[k];
		}
		ave_r[i] = sum/L;
		ave_r2[i] = pow(ave_r[i], 2);
	}
	
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_r[i] += ave_r[j];
			sum_prog_r2[i] += ave_r2[j];
		}
		sum_prog_r[i] /= (i+1);
		sum_prog_r2[i] /= (i+1);
		error[i] = dev_st(sum_prog_r, sum_prog_r2, i);
	}
	
	
	// Salvo i risultati del Data Blocking in "results_db_es.dat" (DataBlocking_ExcitedState_Uniform)
	myfile.open("results_db_es_u.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << i+1 << "\t" << sum_prog_r[i] << "\t" << error[i] << endl;
    }
    myfile.close();
    
    
    // Stampo questo a schermo per verificare che il programma sia andato a buon fine
    cout << "EXCITED STATE (n = 2, l = 1, m = 0)" << endl;
    cout << "Metropolis algorithm implemented by an uniform distribution" << endl;
	cout << "Accepted steps: " << metro1.GetAccepted() << endl;
	cout << "Rejected steps: " << metro1.GetRejected() << endl;
	cout << "Ratio between accepted and rejected steps: " << (double)(metro1.GetAccepted()) / (double)(M) << endl << endl;
	cout << "------------------------------------------" << endl << endl;
	
	
	// Resetto i vettori definiti precedentemente
	r.assign(M, 0.0);
    ave_r.assign(N, 0.0);
    ave_r2.assign(N, 0.0);
    sum_prog_r.assign(N, 0.0);
    sum_prog_r2.assign(N, 0.0);
    error.assign(N, 0.0);
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Eseguo lo stesso procedimento per l'algoritmo implementato da distribuzione gaussiana (stato eccitato)
	
	
	// Oggetto di tipo Metropolis per lo stato eccitato
	Metropolis metro1G(3*a_0, 1);
	
	
	// Produco M step dell'algoritmo di Metropolis a partire da r_0
	metro1G.RunGaussian(M, r_0, 1.9*a_0);
	vector <double> x1G = metro1G.GetX();
	vector <double> y1G = metro1G.GetY();
	vector <double> z1G = metro1G.GetZ();
	
	for (int i = 0; i < M; i++) {
		r[i] = sqrt(x1G[i]*x1G[i] + y1G[i]*y1G[i] + z1G[i]*z1G[i]);
	}
    
    
    // Effettuo l'analisi della posizione dell'elettrone nello stato eccitato attraverso il Data Blocking
	for (int i = 0; i < N; i++) {
		double sum = 0.0;
		
		// Valuto la media delle distanze per lo i-esimo blocco
		for (int j = 0; j < L; j++) {
			int k = j+i*L;
			sum += r[k];
		}
		ave_r[i] = sum/L;
		ave_r2[i] = pow(ave_r[i], 2);
	}
	
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_r[i] += ave_r[j];
			sum_prog_r2[i] += ave_r2[j];
		}
		sum_prog_r[i] /= (i+1);
		sum_prog_r2[i] /= (i+1);
		error[i] = dev_st(sum_prog_r, sum_prog_r2, i);
	}
	
	
	// Salvo i risultati del Data Blocking in "results_db_es_g.dat" (DataBlocking_ExcitedState_Gaussian)
	myfile.open("results_db_es_g.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << i+1 << "\t" << sum_prog_r[i] << "\t" << error[i] << endl;
    }
    myfile.close();
    
    
    // Stampo questo a schermo per verificare che il programma sia andato a buon fine
    cout << "EXCITED STATE (n = 2, l = 1, m = 0)" << endl;
    cout << "Metropolis algorithm implemented by a gaussian distribution" << endl;
	cout << "Accepted steps: " << metro1G.GetAccepted() << endl;
	cout << "Rejected steps: " << metro1G.GetRejected() << endl;
	cout << "Ratio between accepted and rejected steps: " << (double)(metro1G.GetAccepted()) / (double)(M) << endl << endl;
	cout << "------------------------------------------" << endl << endl;
	
	
	
	/*
	// Dati utili
	int M = 1000000;  // Numeri casuali generati dalla distribuzione che si vuole campionare (tutti determinati da step accettati secondo Metropolis)
	int L = 10000;  // Campionamenti per ogni blocco
	int N = M/L;  // Numero di blocchi
	double sum;
	int k;
	
	double a_0 = 0.0529;  // Raggio di Bohr
	int accepted = 0;
	int rejected = 0;
	int total = 0;
	
	vector <double> r(M);  // Array degli step accettati secondo l'algoritmo di Metropolis
	vector <double> ave_r(N);
	vector <double> ave_r2(N);
	vector <double> sum_prog_r(N);
	vector <double> sum_prog_r2(N);
	vector <double> blocchi(N);
	vector <double> error(N);
	
	double x_0 = a_0 / sqrt(3);
	double y_0 = a_0 / sqrt(3);
	double z_0 = a_0 / sqrt(3);
	// double x_0 = a_0;
	// double y_0 = 0;
	// double z_0 = 0;
	
	double x_1, y_1, z_1;
	double delta =  a_0;
	double dx, dy, dz;
	
	cout << "Punto iniziale per lo stato fondamentale: r = " << sqrt(pow(x_0,2) + pow(y_0,2) + pow(z_0,2)) << endl;
	
	
	// Utilizzo l'algoritmo di Metropolis per campionare M valori dalla distribuzione |psi_100|^2 del ground state
	for (int i = 0; i < M; i++) {
		double rand_x = rnd.Rannyu();
		double rand_y = rnd.Rannyu();
		double rand_z = rnd.Rannyu();
		
		dx = 2 * delta * rand_x - delta;
		dy = 2 * delta * rand_y - delta;
		dz = 2 * delta * rand_z - delta;
		
		x_1 = x_0 + dx;
		y_1 = y_0 + dy;
		z_1 = z_0 + dz;
		
		double alpha = min(1.0, pow(psi_100(x_1, y_1, z_1), 2) / pow(psi_100(x_0, y_0, z_0), 2));
		double q = rnd.Rannyu();
		
		if (q <= alpha) {
			r[i] = sqrt(pow(x_1,2) + pow(y_1,2) + pow(z_1,2));
			accepted++;
			x_0 = x_1;
			y_0 = y_1;
			z_0 = z_1;
		}
		else {
			r[i] = sqrt(pow(x_0,2) + pow(y_0,2) + pow(z_0,2));
			rejected++;
		}
		
		total++;
	}

	// cout << "STATO FONDAMENTALE" << endl;
	cout << "I passi accettati sono " <<  accepted << ", mentre i dati rigettati sono " << rejected <<  endl;
	cout << "Il rapporto fra dati accettati e dati totali è " << double(accepted)/double(total) << endl << endl;
	
	cout << "------------------------------------" << endl << endl;
	
	
	// Valuto la media progressiva del raggio dell'elettrone nello stato fondamentale
	for (int i = 0; i < N; i++) {
		sum = 0;
		
		for (int j = 0; j < L; j++) {
			k = j+i*L;
			sum += r[k];
		}
		ave_r[i] = sum/L;
		ave_r2[i] = pow(ave_r[i], 2);
	}
	
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_r[i] += ave_r[j];
			sum_prog_r2[i] += ave_r2[j];
		}
		sum_prog_r[i] /= (i+1);
		sum_prog_r2[i] /= (i+1);
		error[i] = dev_st(sum_prog_r, sum_prog_r2, i);
		blocchi[i] = i+1;
	}
	
	
	// Salvo i risultati ottenuti in "risultati_1.dat"
	ofstream myfile;
	myfile.open("risultati_1.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << blocchi[i] << "\t" << sum_prog_r[i] << "\t" << error[i] << endl;
    }
    
    myfile.close();
    
    
    // Ripeto il procedimento precedente per lo stato eccitato, utilizzando |psi_210|^2
    // Resetto gli array e le variabili
    r.assign(M, 0.0);
    ave_r.assign(N, 0.0);
    ave_r2.assign(N, 0.0);
    sum_prog_r.assign(N, 0.0);
    sum_prog_r2.assign(N, 0.0);
    blocchi.assign(N, 0.0);
    error.assign(N, 0.0);
    
    accepted = 0;
    rejected = 0;
    total = 0;
    
    // Cambio punto di partenza
	x_0 = (3 * a_0) / sqrt(3);
	y_0 = (3 * a_0) / sqrt(3);
	z_0 = (3 * a_0) / sqrt(3);
	
	
	cout << "Punto iniziale per lo stato eccitato: r = " << sqrt(pow(x_0,2) + pow(y_0,2) + pow(z_0,2)) << endl;
	
	
	//Utilizzo l'algoritmo di Metropolis per campionare M valori dalla distribuzione |psi_210|^2 dello stato eccitato
	for (int i = 0; i < M; i++) {
		double rand_x = rnd.Rannyu();
		double rand_y = rnd.Rannyu();
		double rand_z = rnd.Rannyu();
		
		dx = 2 * delta * rand_x - delta;
		dy = 2 * delta * rand_y - delta;
		dz = 2 * delta * rand_z - delta;
		
		x_1 = x_0 + dx;
		y_1 = y_0 + dy;
		z_1 = z_0 + dz;
		
		double alpha = min(1.0, pow(psi_210(x_1, y_1, z_1), 2) / pow(psi_210(x_0, y_0, z_0), 2));
		double q = rnd.Rannyu();
		
		if (q <= alpha) {
			r[i] = sqrt(pow(x_1,2) + pow(y_1,2) + pow(z_1,2));
			accepted++;
			x_0 = x_1;
			y_0 = y_1;
			z_0 = z_1;
		}
		else {
			r[i] = sqrt(pow(x_0,2) + pow(y_0,2) + pow(z_0,2));
			rejected++;
		}
		
		total++;
	}

	// cout << "STATO ECCITATO" << endl;
	cout << "I passi accettati sono " <<  accepted << ", mentre i dati rigettati sono " << rejected <<  endl;
	cout << "Il rapporto fra dati accettati e dati totali è " << double(accepted)/double(total) << endl << endl;
	
	
	// Valuto la media progressiva del raggio dell'elettrone nello stato eccitato
	for (int i = 0; i < N; i++) {
		sum = 0;
		
		for (int j = 0; j < L; j++) {
			k = j+i*L;
			sum += r[k];
		}
		ave_r[i] = sum/L;
		ave_r2[i] = pow(ave_r[i], 2);
	}
	
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_r[i] += ave_r[j];
			sum_prog_r2[i] += ave_r2[j];
		}
		sum_prog_r[i] /= (i+1);
		sum_prog_r2[i] /= (i+1);
		error[i] = dev_st(sum_prog_r, sum_prog_r2, i);
		blocchi[i] = i+1;
	}
	
	
	// Salvo i risultati ottenuti in "risultati_2.dat"
	myfile.open("risultati_2.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << blocchi[i] << "\t" << sum_prog_r[i] << "\t" << error[i] << endl;
    }
    
    myfile.close();
    */
    // FINO A QUI I RISULTATI ERANO CORRETTI
    
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	rnd.SaveSeed();
	return 0;
	
}
