#ifndef __RW__
#define __RW__

#include <vector>
#include "random.h"

using namespace std;

class RW {
	
private:
	// Numero di vettori
    int M;
    
    // Posizioni correnti dei vettori
    vector<vector<double>> positions;
    
    // Oggetto Random per generare numeri casuali
    Random random;

public:
	// Costruttore
    RW(int numVectors);
    
    // Esegue un passo discreto per ciascun vettore
    void DiscreteStep();
    
    // Esegue un passo continuo per ciascun vettore
    void ContinuousStep();
    
    // Restituisce le posizioni correnti dei vettori
    vector<vector<double>> GetPositions() const;
    
    // Restituisce la distanza dell'n-esimo punto dall'origine
    double Distance(int n) const;
    
    // Restituisce la distanza al quadrato dell'n-esimo punto dall'origine
    double Distance_2(int n) const;
    
    // Resetta i vettori riportandoli nell'origine
    void Reset();
};

#endif // __RW__