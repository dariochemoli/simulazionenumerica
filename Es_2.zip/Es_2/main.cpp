#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "random.h"
#include "rw.h"

using namespace std;


// Funzione che restituisce la media dei primi n termini di un vettore
double mean(const vector <double> v, int n) {
	
	if (n == 0) {return 0;}
	else {
		double m = 0.0;
	
		for (int i = 0; i < n; i++) {
			m += v[i];
		}
		m /= n;
		return m;
	}
}


// Funzione che restituisce la deviazione standard della media dei primi n termini di un vettore
double mean_dev_st(const vector<double>& v, int n) {
    if (n <= 0 || n > v.size()) {
        cerr << "Numero di termini non valido!" << endl;
        return 0;
    }
    
    double sum = 0.0;
    double mean = 0.0;

    for (int i = 0; i < n; ++i) {
        sum += v[i];
    }

    mean = sum / n;

    double squared_diff_sum = 0.0;

    // Calcolo la somma dei quadrati delle differenze dalla media
    for (int i = 0; i < n; ++i) {
        double diff = v[i] - mean;
        squared_diff_sum += diff * diff;
    }

    double standard_deviation = sqrt(squared_diff_sum / (n-1));

    return standard_deviation / sqrt(n);
}
 

// Funzione che restituisce la n-esima deviazione standard progressiva
double dev_st(const vector <double> v1, const vector <double> v2, int n) {
	
	if (n == 0) {return 0;}
	else {
		return sqrt((v2[n] - pow(v1[n], 2)) / n);
	}
}
 
int main () {


	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Inizializzo il generatore di numeri casuali fornendogli i quattro interi per generare il seed
	Random rnd;
   
	int seed[4];  // Definisco un vettore 'seed' avente 4 elementi (per ora vuoto)
	int p1, p2;  // Definisco due numeri primi fra loro p1, p2
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	// Definisco i parametri
	int M = 10000;
	int L = 100;
	int N = M/L;
	vector <double> integrals(N);  // Vettore contenente le stime degli integrali
	vector <double> integrals_2(N);
	
	vector <double> sum_prog(N);
	vector <double> sum_prog2(N);
	vector <double> error(N);
	
	
	// Valuto le medie degli integrali negli N blocchi, e li salvo nell'array "integrals"
	for (int i = 0; i < N; i++) {
		double I = 0;
		
		for (int j = 0; j < L; j++) {
			double r = rnd.Rannyu();
			I += (M_PI/2)*cos((M_PI/2)*r)/L; // Stima dell'integrale j-esimo
		}
		integrals[i] = I;  // Media degli integrali dello i-esimo blocco
		integrals_2[i] = pow(integrals[i], 2);
	}
	
	
	// Valuto la media progressiva e la deviaziona standard progressiva
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog[i] += integrals[j];
			sum_prog2[i] += integrals_2[j];
		}
		sum_prog[i] /= (i+1);
		sum_prog2[i] /= (i+1);
		error[i] = dev_st(sum_prog, sum_prog2, i);
	}
	
	

	//Salvo i risultati all'interno del file 'results_integral.dat'
	ofstream myfile;
	myfile.open("results_integral.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << (i+1)*L << "\t" << sum_prog[i] << "\t" << error[i] << endl;
    }
    myfile.close();
    
    
    // Azzero i vettori
    integrals.assign(N, 0.0);
    integrals_2.assign(N, 0.0);
    sum_prog.assign(N, 0.0);
    sum_prog2.assign(N, 0.0);
    error.assign(N, 0.0);
    
    
    // Eseguo lo stesso procedimento per l'importance sampling
	for (int i = 0; i < N; i++) {
        double I = 0.0;

        for (int j = 0; j < L; j++) {
        	/*
        	double x = rnd.Rannyu();
        	I += 2*(1-x); // Stima dell'integrale j-esimo
        	*/
        	double y = rnd.Rannyu();
        	double x = sqrt(1-y) + 1;
            I += (M_PI/2)*cos((M_PI/2)*x) / (2*(1-x));
        }

        integrals[i] = I/L; // Media degli integrali dello i-esimo blocco
        integrals_2[i] = pow(integrals[i], 2);
    }
	
	
	// Valuto la media progressiva e la deviaziona standard progressiva
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog[i] += integrals[j];
			sum_prog2[i] += integrals_2[j];
		}
		sum_prog[i] /= (i+1);
		sum_prog2[i] /= (i+1);
		error[i] = dev_st(sum_prog, sum_prog2, i);
	}
	
	myfile.open("results_integral_gauss.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << (i+1)*L << "\t" << sum_prog[i] << "\t" << error[i] << endl;
    }
    myfile.close();
	
	
	//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
    
    // Elementi utili
    int V = 10000;  // Numero di punti soggetti a random walk
    M = 100;  // Numero di passi massimo
    vector <double> dist(M);  // Vettore delle medie delle distanze al quadrato dei V punti dopo ogni passo
    vector <double> err(M);  // Vettore delle devizioni standartd delle distanze al quadrato dopo ogni passo
    vector <double> dist_step(V);  // Vettore delle distanze al quadrato di tutti i V punti dopo ogni passo
 
    
    // Oggetto di tipo RW (Random Walk)
    RW rw(V);
    
    
    // Calcolo la media e l'incertezza statistica del quadrato della distanza dei V punti dall'origine dopo ogni passo
    for (int i = 0; i < M; i++) {
    	dist_step.assign(V, 0.0);
    	// dist_step2.assign(V, 0.0);
    	rw.DiscreteStep();
    	
    	for (int j = 0; j < V; j++) {
    		double d = rw.Distance_2(j);
    		dist_step[j] = d;  // Raccolgo la distanza al quadrato di ogni punto dopo ogni passo, così da calcolarne la media, che salvo in "dist"
    	}
    	dist[i] = sqrt(mean(dist_step, V));
    	err[i] = (mean_dev_st(dist_step, V)) / (2 * dist[i]);
    }

    
    //Salvo i risultati all'interno del file 'results_discrete_rw.dat'
	myfile.open("results_discrete_rw.dat");
	
	for (int i = 0; i < M; i++) {
        myfile << i+1 << "\t" << dist[i] << "\t" << err[i] << endl;
    }
    myfile.close();
    
    
    
    // Resetto i punti che sono stati soggetti a random walk e i vettori inizializzati precedentemente
    rw.Reset();
    
    dist.assign(M, 0.0);
    err.assign(M, 0.0);
    dist_step.assign(V, 0.0);
    
    
    // Eseguo lo stesso procedimento precedente, ma questa volta simulando un random walk continuo
    for (int i = 0; i < M; i++) {
    	dist_step.assign(V, 0.0);
    	rw.ContinuousStep();
    	
    	for (int j = 0; j < V; j++) {
    		double d = rw.Distance_2(j);
    		dist_step[j] = d;
    	}
    	dist[i] = sqrt(mean(dist_step, V));
    	err[i] = mean_dev_st(dist_step, V) / (2 * dist[i]);
    }

    
    //Salvo i risultati all'interno del file 'results_continuous_rw.dat'
	myfile.open("results_continuous_rw.dat");
	
	for (int i = 0; i < M; i++) {
        myfile << i+1 << "\t" << dist[i] << "\t" << err[i] << endl;
    }
    myfile.close();
    
    
	// Grafico ora i due random walk discreto e continuo associati al primo punto
	// Reimposto il seed iniziale, cosìcche posso simulare gli stessi RW precedenti e raffigurarli su Jupyter Lab
	Primes.open("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();
	// ifstream input("seed.in");
	// string property;
	input.open("seed.in");
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	
	// Resetto l'oggetto rw e salvo man mano le posizioni in "evolution_discrete_rw.dat"
	rw.Reset();

    myfile.open("evolution_discrete_rw.dat");

    for (int i = 0; i < M; i++) {
        rw.DiscreteStep();
        vector <vector <double>> positions = rw.GetPositions();  // Vettore delle posizioni correnti
        myfile << positions[0][0] << "\t " << positions[0][1] << "\t " << positions[0][2] << endl;
    }
    myfile.close();
    
    
    // Faccio lo stesso procediemnto per il random walk continuo
	Primes.open("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();
	// ifstream input("seed.in");
	// string property;
	input.open("seed.in");
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	
	// Salvo man mano le posizioni in "evolution_continuous_rw.dat"
	rw.Reset();

    myfile.open("evolution_continuous_rw.dat");

    for (int i = 0; i < M; i++) {
        rw.ContinuousStep();
        vector <vector <double>> positions = rw.GetPositions();  // Vettore delle posizioni correnti
        myfile << positions[0][0] << "\t " << positions[0][1] << "\t " << positions[0][2] << endl;
    }
    myfile.close();
	
	
	// Salvo il seed
	rnd.SaveSeed();
	
	
	return 0;
}