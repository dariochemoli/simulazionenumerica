#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include "rw.h"


RW::RW(int numVectors) {
    M = numVectors;  // Imposto il numero di vettori
    positions.resize(M, vector<double>(3, 0));  // Inizializzo il vettore delle posizioni a M vettori a tre componenti con valori iniziali pari a 0
    
    // Inizializzo il generatore di numeri casuali per l'oggetto "random"
    int seed[4];
	int p1, p2;
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	random.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
}


void RW::DiscreteStep() {
    // Per ogni vettore, seleziono casualmente una delle tre componenti e incremento o decrementa il valore di quella componente di 1
    for (int i = 0; i < M; i++) {
    	double r = random.Rannyu() * 3;
        int component;  // Genero un numero casuale fra 0 e 3 per ottenere l'indice della componente (0, 1, 2)
        
        if (r < 1) {component = 0;}
        else if (r >= 1 && r < 2) {component = 1;}
        else {component = 2;}
        	
        double s = random.Rannyu();
        int step;  // Genero un numero casuale da 0 a 1 per determinare il passo (1 o -1)
        
        if (s < 0.5) {step = -1;}
        else {step = 1;}
        
        positions[i][component] += step;  // Aggiorna il valore della componente selezionata
    }
}


void RW::ContinuousStep() {
    // Per ogni vettore, genero casualmente l'angolo polare e l'angolo azimutale
    for (int i = 0; i < M; i++) {
        double theta = acos(1 - 2*random.Rannyu());  // Angolo polare in [0, pi] (distribuito secondo la densità di probabilità P = 1/2 sin(theta))
        double phi = random.Rannyu() * 2 * M_PI;  // Angolo azimutale in [0, 2pi] (distribuito uniformemente)

        // Calcolo le componenti cartesiane del vettore unitario
        double x = sin(theta) * cos(phi);
        double y = sin(theta) * sin(phi);
        double z = cos(theta);

        // Aggiorno la posizione del vettore
        positions[i][0] += x;
        positions[i][1] += y;
        positions[i][2] += z;
    }
}



vector<vector<double>> RW::GetPositions() const {
    return positions;
}


double RW::Distance(int n) const {
	double x = positions[n][0];
	double y = positions[n][1];
	double z = positions[n][2];
	
	return sqrt(x*x + y*y + z*z);
}


double RW::Distance_2(int n) const {
	double x = positions[n][0];
	double y = positions[n][1];
	double z = positions[n][2];
	
	return x*x + y*y + z*z;
}


void RW::Reset() {
    for (int i = 0; i < M; i++) {
        positions[i][0] = 0;
        positions[i][1] = 0;
        positions[i][2] = 0;
    }
}
