#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include "random.h"

using namespace std;


// Funzione che restituisce la deviazione standard dell'osservabile v, dopo n estrapolazioni
double dev_st(const vector <double> v1, const vector <double> v2, int n) {
	
	if (n == 0) {
		return 0;
	}
	else {
		return sqrt((v2[n] - pow(v1[n], 2)) / n);
	}
}
 
 
int main (/* int argc, char *argv[] */) {


	// Inizializzo il generatore di numeri casuali
	Random rnd;
   
	int seed[4];  // Definisco un vettore 'seed' avente 4 elementi (per ora vuoto)
	int p1, p2;  // Definisco due numeri primi fra loro p1, p2
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	

	// Elementi utili
	int M = 1000000;  // Numeri casuali generati in totale
	int L = 10000;  // Numeri casuali per ogni blocco
	int N = M/L;  // Numero di blocchi
	vector <double> ave(N);
	vector <double> ave2(N);
	vector <double> sum_prog(N);
	vector <double> sum_prog2(N);
	vector <double> error(N);
	vector <double> blocchi(N);
	double sum1;
	
	
	// Il vettore ave contiene N valori della media di L numeri casuali fra 0 e 1, mentre ave2 contiene i valori di ave al quadrato
	for (int i = 0; i < N; i++) {
		sum1 = 0.0;
		
		for (int j = 0; j < L; j++) {  // sum1 alla fine del ciclo è la somma di L numeri compresi fra 0 e 1
			double r = rnd.Rannyu();
			sum1 += r;
		}
		ave[i] = sum1/L;
		ave2[i] = pow(ave[i], 2);
	}
	
	
	// Raccologo le medie progressive della media del generatore nell'array sum_prog e le deviazioni standard di queste nell'array error
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog[i] += ave[j];
			sum_prog2[i] += ave2[j];
		}
		sum_prog[i] /= (i+1);  // Lo i-esimo valore di sum_prog contiene la media dei primi i valori delle medie del generatore
		sum_prog2[i] /= (i+1);  // Lo i-esimo valore di sum_prog2 contiene la media al quadrato dei primi i elementi di ave
		error[i] = dev_st(sum_prog, sum_prog2, i);  // Lo i-esimo valore di error contiene la deviazione standard della media del generatore valutata su i estrapolazioni
		blocchi[i] = i;
	}
	
	
	// Salvo i risultati ottenuti in risultati_1.dat
	ofstream myfile;
	myfile.open("results_1.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << blocchi[i] << "\t" << sum_prog[i] << "\t" << error[i] << endl;
    }
    
    myfile.close();
    
    
    // Procedo nello stesso modo valutando le medie progressive della varianza del generatore con le relative deviazioni standard
	for (int i = 0; i < N; i++) {
		sum1 = 0.0;
		
		for (int j = 0; j < L; j++) {  // sum1 alla fine del ciclo è la somma di L numeri compresi fra 0 e 1 a cui sottraggo 0.5
			double r = rnd.Rannyu();
			sum1 += pow(r - 0.5, 2);
		}
		ave[i] = sum1/L;
		ave2[i] = pow(ave[i], 2);
	}
	
	// Resetto i vettori 'sum_prog' e 'sum_prog_2' e li riempio con i nuovi valori dei vettori ave e ave2
	sum_prog.assign(N, 0.0);
	sum_prog2.assign(N, 0.0);
	
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog[i] += ave[j];
			sum_prog2[i] += ave2[j];
		}
		sum_prog[i] /= (i+1);  // Lo i-esimo valore di sum_prog contiene la media dei primi i valori delle medie del generatore a cui sottraggo 0.5
		sum_prog2[i] /= (i+1);  // Lo i-esimo valore di sum_prog2 contiene la media al quadrato dei primi i elementi di ave
		error[i] = dev_st(sum_prog, sum_prog2, i);  // Lo i-esimo valore di error contiene la deviazione standard della media del generatore -0.5 su i estrapolazioni
		blocchi[i] = i;
	}
	
	
	// Salvo i risultati ottenuti in risultati_2.dat
	myfile.open("results_2.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << blocchi[i] << "\t" << sum_prog[i] << "\t" << error[i] << endl;
    }
    
    myfile.close();
    
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    
    // Elementi utili per valutare il chi-quadro dei numeri estratti dal generatore
    M = 100;  // Intervallini in cui si suddivide [0,1]
    int n = 10000;  // Numeri casuali da estrarre per valutare un singolo chi-quadro
    N = 10000;  // Numero di chi-quadro calcolati
    double chi;
    double interval_len = 1.0 / M;  // Lunghezza del singolo intervallino
    vector <double> pearson(N);  // Array in cui salvare i risultati del chi-quadro
    vector <int> interval(M);  // Array su cui salvare quante volte un numero random estratto finisce negli M intervalli di [0,1]
    
    
    // Valuto la distribuzione chi-quadro per 100 gradi di libertà
    for (int i = 0; i < N; i++) {
    	interval.assign(M, 0);
    	chi = 0.0;
    	
    	for (int j = 0; j < n; j++) {  // Valuto quante volte un numero casuale cade in un determinato intervallino, così da valutare il chi-quadro
    		double r = rnd.Rannyu();
    		int index = (int)(r / interval_len);
    		interval[index] += 1;
    	}
    	for (int k = 0; k < M; k++) {
    		chi += pow(interval[k] - n/M, 2) / (n/M);
    	}
    	pearson[i] = chi;
    }
    
    
    myfile.open("results_3.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << pearson[i] << endl;
    }
    
    myfile.close();
    
    
    // Valuto la distribuzione chi-quadro con 10 grado di libertà
    pearson.assign(N, 0.0);
    M = 10;
    interval_len = 1.0 / M;
    
    for (int i = 0; i < N; i++) {
    	interval.assign(M, 0);
    	chi = 0.0;
    	
    	for (int j = 0; j < n; j++) {
    		double r = rnd.Rannyu();
    		int index = (int)(r / interval_len);
    		interval[index] += 1;
    	}
    	for (int k = 0; k < M; k++) {
    		chi += pow(interval[k] - n/M, 2) / (n/M);
    	}
    	pearson[i] = chi;
    }
    
    myfile.open("results_4.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << pearson[i] << endl;
    }
    
    myfile.close();
    
    
    // Valuto la distribuzione chi-quadro con 30 gradi di libertà
    pearson.assign(N, 0.0);
    M = 30;
    interval_len = 1.0 / M;
    
    for (int i = 0; i < N; i++) {
    	interval.assign(M, 0);
    	chi = 0.0;
    	
    	for (int j = 0; j < n; j++) {
    		double r = rnd.Rannyu();
    		int index = (int)(r / interval_len);
    		interval[index] += 1;
    	}
    	for (int k = 0; k < M; k++) {
    		chi += pow(interval[k] - n/M, 2) / (n/M);
    	}
    	pearson[i] = chi;
    }
    
    myfile.open("results_5.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << pearson[i] << endl;
    }
    
    myfile.close();
    
    
    // Valuto la distribuzione chi-quadro con 50 gradi di libertà
    pearson.assign(N, 0.0);
    M = 50;
    interval_len = 1.0 / M;
    
    for (int i = 0; i < N; i++) {
    	interval.assign(M, 0);
    	chi = 0.0;
    	
    	for (int j = 0; j < n; j++) {
    		double r = rnd.Rannyu();
    		int index = (int)(r / interval_len);
    		interval[index] += 1;
    	}
    	for (int k = 0; k < M; k++) {
    		chi += pow(interval[k] - n/M, 2) / (n/M);
    	}
    	pearson[i] = chi;
    }
    
    myfile.open("results_6.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << pearson[i] << endl;
    }
    
    myfile.close();
    
    
    //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    
    
    // Per generare numeri casuali dal dado standard e da distribuzioni esponenziale e lorenziana ho aggiunto i metodi Exp e Lorentian nella clarrse Random
    N = 10000;
    int N_1 = 1;
    int N_2 = 2;
    int N_3 = 10;
    int N_4 = 100;
    double lambda = 1.0;  // Parametro distribuzione esponenziale
    double u = 0.0;  // Parametro distribuzione lorenziana
    double gamma = 1.0;  // Idem come sopra
    // double A_N;
    double sum;
    
    // Vettori contenenti le distribuzioni A_N generate dal dado standard (per N_1, N_2, N_3, N_4)
    vector <double> dice_1(N);  // 
    vector <double> dice_2(N);
    vector <double> dice_3(N);
    vector <double> dice_4(N);
    
    // Vettori contenenti le distribuzioni A_N generate dalla distribuzione esponenziale (per N_1, N_2, N_3, N_4)
    vector <double> exp_1(N);
    vector <double> exp_2(N);
    vector <double> exp_3(N);
    vector <double> exp_4(N);
    
    // Vettori contenenti le distribuzioni A_N generate dalla distribuzione lorenziana (per N_1, N_2, N_3, N_4)
    vector <double> lor_1(N);
    vector <double> lor_2(N);
    vector <double> lor_3(N);
    vector <double> lor_4(N);
    
    // Vettori contenenti le distribuzioni gaussiane da paragonare a quelle in dice_4 e exp_4
    vector <double> gauss_1(N);
    vector <double> gauss_2(N);
    
    
    // Riempio i vettori dice, e salvo i risultati su quattro colonne del file "results_dice.dat"
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_1; j++) {
    		int r = rnd.Dice();
    		sum += r;
    	}
    	sum /= N_1;
    	dice_1[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_2; j++) {
    		int r = rnd.Dice();
    		sum += r;
    	}
    	sum /= N_2;
    	dice_2[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_3; j++) {
    		int r = rnd.Dice();
    		sum += r;
    	}
    	sum /= N_3;
    	dice_3[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_4; j++) {
    		int r = rnd.Dice();
    		sum += r;
    	}
    	sum /= N_4;
    	dice_4[i] = sum;
    }
    
    myfile.open("results_dice.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << dice_1[i] << "\t" << dice_2[i] << "\t" << dice_3[i] << "\t" << dice_4[i] << endl;
    }
    myfile.close();
    
    
    // Riempio i vettori exp, e salvo i risultati su quattro colonne del file "results_exp.dat"
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_1; j++) {
    		double r = rnd.Exp(lambda);
    		sum += r;
    	}
    	sum /= N_1;
    	exp_1[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_2; j++) {
    		double r = rnd.Exp(lambda);
    		sum += r;
    	}
    	sum /= N_2;
    	exp_2[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_3; j++) {
    		double r = rnd.Exp(lambda);
    		sum += r;
    	}
    	sum /= N_3;
    	exp_3[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_4; j++) {
    		double r = rnd.Exp(lambda);
    		sum += r;
    	}
    	sum /= N_4;
    	exp_4[i] = sum;
    }
    
    myfile.open("results_exp.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << exp_1[i] << "\t" << exp_2[i] << "\t" << exp_3[i] << "\t" << exp_4[i] << endl;
    }
    myfile.close();
    
    
    // Riempio i vettori lor, e salvo i risultati su quattro colonne del file "results_lor.dat"
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_1; j++) {
    		double r = rnd.Lorentian(u, gamma);
    		sum += r;
    	}
    	sum /= N_1;
    	lor_1[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_2; j++) {
    		double r = rnd.Lorentian(u, gamma);
    		sum += r;
    	}
    	sum /= N_2;
    	lor_2[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_3; j++) {
    		double r = rnd.Lorentian(u, gamma);
    		sum += r;
    	}
    	sum /= N_3;
    	lor_3[i] = sum;
    }
    
    for (int i = 0; i < N; i++) {
    	sum = 0.0;
    	
    	for (int j = 0; j < N_4; j++) {
    		double r = rnd.Lorentian(u, gamma);
    		sum += r;
    	}
    	sum /= N_4;
    	lor_4[i] = sum;
    }
    
    myfile.open("results_lor.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << lor_1[i] << "\t" << lor_2[i] << "\t" << lor_3[i] << "\t" << lor_4[i] << endl;
    }
    myfile.close();
    
    
    // Riempio i vettori gauss, e salvo i risultati su quattro colonne del file "results_gauss.dat"
    double mean_1 = 3.5;
    double sigma_1 = 5/sqrt(12*N_4);
    double mean_2 = 1.0;
    double sigma_2 = 1/sqrt(N_4);
    
    for (int i = 0; i < N; i++) {
    	double r = rnd.Gauss(mean_1, sigma_1);
    	gauss_1[i] = r;
    }
    
    for (int i = 0; i < N; i++) {
    	double r = rnd.Gauss(mean_2, sigma_2);
    	gauss_2[i] = r;
    }

    myfile.open("results_gauss.dat");
	
	for (int i = 0; i < N; i++) {
        myfile << gauss_1[i] << "\t" << gauss_2[i] << endl;
    }
    myfile.close();
    
    
	
	// Genero il file 'seed.out' con il quale posso eventualmente rigenerare il seed finale	
	rnd.SaveSeed();
	
	
	return 0;
	
}

	
	
	/*
	r = np.random.rand(M) # Vettore M-dimensionale contenente valori distribuiti fra 0 e 1
	x = np.arange(N)      # vettore della forma [0,1,2,...,N-1]
	ave = np.zeros(N)
	av2 = np.zeros(N)
	sum_prog = np.zeros(N)
	su2_prog = np.zeros(N)
	err_prog = np.zeros(N)
	
	for i in range(N):
    sum1 = 0
    sum2 = 0
    for j in range(L):
        k = j+i*L  # k(j) è il j-esimo elemento dello i-esimo blocco
        sum1 += r[k]
        sum2 += r[k]*r[k]
    ave[i] = sum1/L  # L'elemento i-esimo di 'ave' è la media sul blocco i-esimo
    av2[i] = (ave[i])**2  # L'lelemento i-esimo di av2 è il quadrato della media sul blocco i-esimo

	for i in range(N):
    for j in range(i+1):
        sum_prog[i] += ave[j] # 'sum_prog' è un vettore che contiene le somme progressive degli elementi di 'ave'
        su2_prog[i] += av2[j] # 'su2_prog' è un vettore che contiene le somme progressive degli elementi di 'av2'
    sum_prog[i]/=(i+1) # Si aggiornano gli elementi di 'sum_prog' in modo tale da avere le medie cumulative
    su2_prog[i]/=(i+1) # Si aggiornano ... di 'su2_prog' ... le medie cumulative al quadrato degli elementi
    # Es: l'elemento 0 di 'sum_prog' è la media dei primi due elementi di 'ave'
    # Ovvero è la media delle medie dei primi due blocchi
    # Il secondo elemento è quindi la media delle medie dei primi tre blocchi, e così via
    err_prog[i] = error(sum_prog,su2_prog,i)
    # Lo i-esimo elemento di 'err_prog' è la varianza sulla media dei primi i+1 blocchi

	x*=L  # Moltiplico il vettore x per il numero di blocchi così che lo i-esimo elemento di x contenga il numero di
    # numeri casuali dopo un numero di i blocchi 
    
    
    ave = np.zeros(N)
av2 = np.zeros(N)
sum_prog = np.zeros(N)
su2_prog = np.zeros(N)
err_prog = np.zeros(N)

for i in range(N):
    sum = 0
    for j in range(L):
        k = j+i*L
        sum += (r[k]-0.5)**2 # Accumulate measures
    ave[i] = sum/L           # Estimate in each block 
    av2[i] = (ave[i])**2 

for i in range(N):
    for j in range(i+1):
        sum_prog[i] += ave[j] 
        su2_prog[i] += av2[j] 
    sum_prog[i]/=(i+1) # Cumulative average
    su2_prog[i]/=(i+1) # Cumulative square average
    err_prog[i] = error(sum_prog,su2_prog,i) # Statistical uncertainty
    
plt.errorbar(x,sum_prog-1/12,yerr=err_prog)
plt.xlabel('#throws')
plt.ylabel('<(r-0.5)^2>-1/12')
plt.grid(True)
plt.show()
*/
