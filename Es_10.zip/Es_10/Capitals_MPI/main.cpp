#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include <algorithm>
#include <mpi.h>
#include "random.h"
#include "chromosomes.h"
using namespace std;
 
 
int main (int argc, char** argv) {
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Inizializzo la MPI
	
	
    int size, rank;
	MPI_Init(&argc,&argv); MPI_Comm_size(MPI_COMM_WORLD, &size);
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);
	
	if (size != 2) {
        cerr << "Questo programma richiede esattamente 2 processi." << endl;
        MPI_Finalize();
        return 1;
    }


	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Inizializzo il generatore di numeri casuali
	
	
	Random rnd;
   
	int seed[4];  // Definisco un vettore 'seed' avente 4 elementi (per ora vuoto)
	int p1, p2, p3, p4;  // Definisco due numeri primi fra loro p1, p2
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 >> p3 >> p4;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	if (rank == 0) rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
        	else rnd.SetRandom(seed,p3,p4);
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
    
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Estraggo le capitali americane
	
	
	// Vettore contenente le 50 coordinate delle città
	vector <vector <double> > C;

	// Leggo in input il file 'American_capitals.dat'
	ifstream inputFile("American_capitals_2.dat");
	
    if (!inputFile.is_open()) {
        cerr << "Impossibile aprire il file." << endl;
        return 1;
    }

	// Il processo 0 legge dal file 'American_capitals.dat' le coordinate delle 50 città, e le salvo nel vettore C
	// Tale vettore sarà mandato al processo 1
	if (rank == 0) {
		// Definisco la prima riga del file, che non ci interessa
		string line;
    	// Scarto la prima riga del file
    	getline(inputFile, line);


		// PROBLEMATICHE SORTE NEL LEGGERE CORRETTAMENTE "American_capitals_.dat"
		/*
		// Il ciclo while continua finchè ci sono righe da leggere nel file, che vengono memorizzate nella variabile 'line'
    	while (getline(inputFile, line)) {
    		// Creo un oggetto istringstream chiamato 'iss' che analizza la linea letta dal file
        	// istringstream iss(line); (Non posso usare questo comando perchè il compilatore 'mpic++' è troppo datato)
        	
        	// Variabili della linea del file
        	// string name, description;
        	double x, y;
        	
        	// if (iss >> name >> description >> x >> y) {
        	// Determino con la prossima funzione se dalla singola riga del file posso estrarre due variabili double
        	if (sscanf(line.c_str(), "%*s %*s %lf %lf", &x, &y) == 2) {
            	// vector <double> coordinates = {x, y};
            	vector <double> coordinates;
            	coordinates.push_back(x);
            	coordinates.push_back(y);
            	
            	C.push_back(coordinates);
        	}
    	}
    	*/
    	
    	
    	// Definisco le coordinate delle città
    	double x, y;
    	
    	// Il ciclo while continua finchè ci sono righe da leggere nel file 'American_capitals_2.dat'
    	while (inputFile >> x >> y) {
        	// vector<double> coordinates = {longitude, latitude};
        	vector <double> coordinates;
            coordinates.push_back(x);
            coordinates.push_back(y);
            
        	C.push_back(coordinates);
    	}
    	inputFile.close();
		
		// Mando il vettore C siffatto al processo 1, mandando separatamente la taglia di C e i vettori contenenti in C
		int numVectorsToSend = C.size();
        MPI_Send(&numVectorsToSend, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);

        for (int i = 0; i < numVectorsToSend; i++) MPI_Send(C[i].data(), 2, MPI_DOUBLE, 1, 0, MPI_COMM_WORLD);
	}
	
	else {
		// Il processo 1 riceve il numero di vettori nel vettore C dal processo 0
        int numVectorsToReceive;
        MPI_Recv(&numVectorsToReceive, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
        
        // Dunque riceve i vettori stessi dal processo 0 e ricostruisce il vettore C
        for (int i = 0; i < numVectorsToReceive; i++) {
            vector <double> v(2);
            MPI_Recv(v.data(), 2, MPI_DOUBLE, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
            C.push_back(v);
        }
	}
	
	ofstream myfile, min_loss, mean_loss;
	
	// Salvo su file i punti che determinano le capiali americane
	if (rank == 0) {
		// ofstream myfile;
		myfile.open("points_capitals.dat");
	
		for (int i = 0; i < C.size(); i++) {
        	myfile << C[i][0] << "\t" << C[i][1] << endl;
    	}
    	myfile.close();
    }
    
    
    
    ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Implemento l'algoritmo genetico per risolvere il travelling salesman problem sulla circonferenza
    
   	
    // Definisco un oggetto Chromosome e applico lo Shuffle a tutti
	Chromosomes cromo(C.size());
	// Mischio i valori di tutti i cromosomi
	cromo.ShuffleAll();
	// Implemento il vettore delle città (punti sulla circonferenza)
	cromo.SetCities(C);
	
	int u, v, Q;
	double q, mlf;
	vector <vector <int> > newpop;  // Vettore in cui salvo i nuovi cromosomi di volta in volta
	vector <int> new1;
	vector <int> new2;
	
	if (rank == 0) {
		// ofstream min_loss, mean_loss;
		min_loss.open("min_loss_function.dat");
		mean_loss.open("mean_loss_function.dat");
	}
	
	
	// Implemento un ciclo di 500 iterazioni dell'algoritmo genetico
	for (int i = 0; i < 500; i++) {
        
		// Ordino i cromosomi
		cromo.Sort();
		
		// Dopo 50 iterazioni il processo con rank 0 riceve un cromosoma da un altro processo se questo ha Loss Function minore
		// Definisco il tag per mandare e ricevere la Loss Function
		int itag_loss = 0;
		// Definisco il tag per mandare e ricevere il cromosoma
		int itag_cromo = 1;
		// Definisco la loss function da mandare e quella da ricevere (la loss del cromosoma migliore)
		double loss_send = cromo.LossFunction(cromo.GetNum() - 1);
		double loss_rec;
		// Definisco il cromosoma da mandare e ricevere
		vector <int> cromo_send = cromo.GetChromosome(cromo.GetNum() - 1);
		vector <int> cromo_rec(cromo.GetSize());
		
		// Invio la loss function dal processo 1 al processo 0
		if (i % 10 == 0 and rank == 1) {
			// Mando la Loss Function
			MPI_Send(&loss_send, 1, MPI_DOUBLE, 0, itag_loss, MPI_COMM_WORLD);
			// Mando il cromosoma
			MPI_Send(cromo_send.data(), cromo.GetSize(), MPI_INT, 0, itag_cromo, MPI_COMM_WORLD);
		}
		// Il processo 0 riceve il valore della loss function dal processo 1
		else if (i % 10 == 0 and rank == 0) {
			// Ricevo la Loss Function
			MPI_Recv(&loss_rec, 1, MPI_DOUBLE, 1, itag_loss, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			// Ricevo il cromosoma
			MPI_Recv(cromo_rec.data(), cromo.GetSize(), MPI_INT, 1, itag_cromo, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
			
			// Se la loss function ricevuta dal pocesso 1 è minore di quella del cromosoma migliore del processo 0 il cromosoma viene sostituito nella popolazione
			if (loss_rec < cromo.LossFunction(cromo.GetNum() - 1)) cromo.Substitute(cromo_rec, cromo.GetNum() - 1);
		}
		
		// Salvo la loss function minima e la media delle loss function della i-esima generazione
		if (rank == 0) {
			min_loss << i+1 << "\t" << cromo.LossFunction(cromo.GetNum() - 1) << endl;
			mlf = 0.0;
		
			for (int j = 0; j < cromo.GetNum(); j++) {
				mlf += cromo.LossFunction(j) / (double)(cromo.GetNum());
			}
			mean_loss << i+1 << "\t" << mlf << endl;
		}
		
		// Implemento un ciclo in modo tale da creare una nuova popolazione di GetNum individui
		for (int i = 0; i < cromo.GetNum()/2; i++) {
			// Scelgo u,v in modo tale che è molto probabile che si scelgano i cromosomi migliori (con Loss Function bassa)
			u = int(pow(rnd.Rannyu(), 0.2) * cromo.GetNum());
			v = int(pow(rnd.Rannyu(), 0.2) * cromo.GetNum());
			q = rnd.Rannyu();
			Q = (int)(rnd.Rannyu(1, 5));
		
			// Mi assicuro che u e v non siano uguali fra loro
			if (u == v and v != 0) v -= 1;
			// else if (u == v and v == 0) v += 1;
		
			// Eseguo un crossover fra i due cromosomi con indici u,v con probabilità 0.75
			if (q < 0.75) {
				new1 = cromo.Crossover(u, v)[0];
				new2 = cromo.Crossover(u, v)[1];
			}
			else {
				new1 = cromo.GetChromosome(u);
				new2 = cromo.GetChromosome(v);
			}
		
			// Eseguo una mutazione sui cromosomi u,v con probabilità 0.2
			if (q < 0.2 and Q == 1) {
				new1 = cromo.Mutation1(new1);
				new2 = cromo.Mutation1(new2);
			}
			if (q < 0.2 and Q == 2) {
				new1 = cromo.Mutation2(new1);
				new2 = cromo.Mutation2(new2);
			}
			if (q < 0.2 and Q == 3) {
				new1 = cromo.Mutation3(new1);
				new2 = cromo.Mutation3(new2);
			}
			if (q < 0.2 and Q == 4) {
				new1 = cromo.Mutation4(new1);
				new2 = cromo.Mutation4(new2);
			}
			
			// Controllo la validità dei nuovi cromosomi
			cromo.Check(new1);
			cromo.Check(new2);
			
			// Aggiungo i due cromosomi soggetti eventualmente al crossover e alla mutazione alla nuova popolazione
			newpop.push_back(new1);
			newpop.push_back(new2);
			
		}
		cromo.NewPopulation(newpop);
		newpop.clear();
	}
	
	if (rank == 0) {
		min_loss.close();
		mean_loss.close();
	}
 	
 	
 	// Ordino ancora una volta i cromosomi e scelgo ora la soluzione al problema come quella codificata dall'ultimo cromosoma
 	cromo.Sort();
 	
	int bestIndex = cromo.GetNum() - 1;

	// Estraggo la sequenza di città dal cromosoma migliore
	vector<int> bestChromosome = cromo.GetChromosome(bestIndex);
	
	// Estraggo ora l'ordine delle città
	vector <vector <double> > result_c = cromo.GetCities(bestIndex);
	
	// Salvo il risultato ottimizzato
	if (rank == 0) {
		myfile.open("result_capitals.dat");

		for (int i = 0; i < cromo.GetSize(); i++) {
			myfile << result_c[i][0] << "\t" << result_c[i][1] << endl;
		}
		myfile.close();
	}
	
 	
 	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	rnd.SaveSeed();
	MPI_Finalize();
	return 0;
}