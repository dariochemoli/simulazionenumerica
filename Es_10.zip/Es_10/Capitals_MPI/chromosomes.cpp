#include <iostream>
#include <fstream>
#include <cmath>
#include <cstdlib>
#include <algorithm>
#include "chromosomes.h"
using namespace std;


Chromosomes::Chromosomes(int size) {
	
	// Inizializzo il generatore di numeri casuali per l'oggetto "random"
    int seed[4];
	int p1, p2;
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	random.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	// Definisco il numero di cromosomi e la loro dimensione
    numChromosomes = 1000;
    chromosomeSize = size;
    InitializeChromosomes();
}



vector<int>& Chromosomes::GetChromosome(int index) {
    if (index >= 0 and index < chromosomes.size()) {
        return chromosomes[index];
    } else {
        cerr << "Indice non valido." << endl;
        exit(1);
    }
}



void Chromosomes::Shuffle(int index) {
        vector<int>& chromosome = chromosomes[index];
        for (int i = 1; i < chromosomeSize; i++) {
        	int randomIndex = int(random.Rannyu() * (chromosomeSize - 1)) + 1;  // Escludo il primo indice, che devo tenere fissato
    		int temp = chromosome[i];
    		chromosome[i] = chromosome[randomIndex];
    		chromosome[randomIndex] = temp;
        }
}



void Chromosomes::ShuffleAll() {
    for (int index = 0; index < numChromosomes; index++) {
        Shuffle(index);
    }
}



vector <vector <int> > Chromosomes::Crossover(int index1, int index2) {
	vector <vector <int> > cross;
	// Cromosomi genitori
    vector <int> parent1 = chromosomes[index1];
    vector <int> parent2 = chromosomes[index2];
    
    // Genero un punto di crossover casuale
    int crossoverPoint = int(random.Rannyu() * (chromosomeSize - 1)) + 1;
    
    // Definisco i figli
    vector <int> child1;
    vector <int> child2;
    
    // Riempio i figli con i primi crossoverPoint valori dei genitori
    for (int i = 0; i < crossoverPoint; i++) {
    	child1.push_back(parent1[i]);
    	child2.push_back(parent2[i]);
    }
    
    // Riempio i figli con i valori mancanti presi in ordine dai genitori
    for (int i = 0; i < chromosomeSize; i++) {
    	if (in(parent2[i], child1) == false) child1.push_back(parent2[i]);
    	if (in(parent1[i], child2) == false) child2.push_back(parent1[i]);
    }
    cross.push_back(child1);
    cross.push_back(child2);
    return cross;
}



void Chromosomes::InitializeChromosomes() {
    chromosomes.reserve(numChromosomes);

    for (int i = 1; i <= numChromosomes; ++i) {
        vector<int> chromosome;
        chromosome.reserve(chromosomeSize);

        for (int j = 1; j <= chromosomeSize; ++j) {
            chromosome.push_back(j);
        }
        chromosomes.push_back(chromosome);
    }
}



void Chromosomes::PrintChromosome(int index) {
    if (index >= 0 && index < chromosomes.size()) {
        const vector<int>& chromosome = chromosomes[index];
        cout << "Cromosoma " << index + 1 << ": ";
        for (int value : chromosome) {
            cout << value << " ";
        }
        cout << endl;
    } else {
        cerr << "Indice non valido." << endl;
    }
}



void Chromosomes::SetCities(vector<vector <double> > points) {
	cities = points;
}


vector <vector <double> > Chromosomes::GetCities(int index) {
	vector <vector <double> > points;
	
	for (int i = 0; i < chromosomeSize; i++) {
		int n;
		n = chromosomes[index][i];
		points.push_back(cities[n-1]);
	}
	return points;
}



vector <int> Chromosomes::Mutation1(vector <int>& vec) {
 	int index1 = int(random.Rannyu() * (chromosomeSize - 1)) + 1;
 	int index2 = int(random.Rannyu() * (chromosomeSize - 1)) + 1;
 	
 	if (index1 != index2) {
 		swap(vec[index1], vec[index2]);
 	}
 	return vec;
 }
 
 
 
 vector <int> Chromosomes::Mutation2(vector <int>& vec) {
    int m = (int)(random.Rannyu(2, chromosomeSize));  // Gli ultimi m elementi del cromosoma cui sono soggetti a shift [2, chromosomeSize - 1]
    int n = (int)(random.Rannyu(1, m));  // Numero di shifts [1, m - 1]
	// int n = 3;
	// int m = 5;
    // Calcolo l'indice di partenza dell'elemento da spostare
    int startIndex = chromosomeSize - m;
    
    // Eseguo uno shift circolare n volte degli ultimi m elementi del cromosoma
    for (int i = 0; i < n; i++){
    	rotate(vec.begin() + startIndex, vec.begin() + startIndex + 1, vec.begin() + chromosomeSize);
    }
    return vec;
}



vector <int> Chromosomes::Mutation3(vector <int>& vec) {
	int n = (int)(random.Rannyu(1, chromosomeSize-3));  // Punto del cromosoma dove considero il primo intervallo soggetto alla mutazione [1, chromosomeSize - 4]
	int width = (int)(random.Rannyu(2, (double)(chromosomeSize-n)/2.0));  // Larghezza dell'intervallo
	int m = (int)(random.Rannyu(n+width+1, chromosomeSize-width));  // Punto del cromosoma dove considero il secondo intervallo (anch'esso di lunghezza width)
	
	for (int i = 0; i < width; i++) {
		swap(vec[n+i], vec[m+i]);
	}
	return vec;
}



vector <int> Chromosomes::Mutation4(vector <int>& vec) {
	int n = (int)(random.Rannyu(1, chromosomeSize-2));  // Inizio intervallo [1, chromosomeSize - 3]
	int m = (int)(random.Rannyu(chromosomeSize-2, chromosomeSize));  // Fine intervallo [chromosomeSize - 2, chromosomeSize - 1]
	for (int i = 0; i < (m-n)/2; i++) {
		swap(vec[n+i], vec[m-i]);
	}
	return vec;
}



double Chromosomes::LossFunction(int index) {
 	double distance = 0.0;
 
 	for (int i = 0; i < chromosomeSize; i++) {
 		int n, m;
 		
 		if (i != chromosomeSize - 1) {
 			n = chromosomes[index][i];
 			m = chromosomes[index][i+1];
 		}
 		else {
 			n = chromosomes[index][i];
 			m = chromosomes[index][0];
 		}
 		distance += dist(cities[n-1], cities[m-1]);
 	}
 	return distance;
}



int Chromosomes::GetNum() {
	return numChromosomes;
}



int Chromosomes::GetSize() {
	return chromosomeSize;
}



void Chromosomes::Sort() {
    
    for (int i = 0; i < numChromosomes - 1; i++) {
    	
        for (int j = 0; j < numChromosomes - i - 1; j++) {
        	
            if (LossFunction(j) < LossFunction(j + 1)) {
                // Scambio i valori se l'elemento corrente è maggiore del successivo
                vector <int> temp = chromosomes[j];
                chromosomes[j] = chromosomes[j + 1];
                chromosomes[j + 1] = temp;
            }
        }
    }
}



void Chromosomes::NewPopulation(vector <vector <int> > newChromosomes) {
	bool statament = true;
	
	for (int i = 0; i < newChromosomes.size(); i++) {
		if (newChromosomes[i].size() != chromosomeSize) statament = false;
	}
	
	if (newChromosomes.size() == numChromosomes and statament == true) chromosomes = newChromosomes;
	else cerr << "Old population and new population sizes don't match!" << endl;
}



void Chromosomes::Substitute(vector <int> chromosome, int n) {
	
	if (n > numChromosomes) {
		cerr << "The chromosome you want to substitute from the population doesn't exist!" << endl;
		return;
	}
		
	if (chromosome.size() != chromosomeSize) {
		cerr << "The size of this new chromosome doesn't match the one of the population!" << endl;
		return;
	}
	chromosomes[n] = chromosome;
}



void Chromosomes::Check(vector<int> chromosome) {
    // Crea un vettore di flag inizializzati a falso
    vector <bool> visited(chromosomeSize + 1, false);

    // Verifico se ogni numero intero da 1 a chromosomeSize è presente una sola volta nel cromosoma
    for (int gene : chromosome) {
        if (gene < 1 or gene > chromosomeSize || visited[gene]) {
            cerr << "Invalid chromosome!" << endl;
            return;
        }
        visited[gene] = true;
    }

    // Verifico se tutti i numeri da 1 a chromosomeSize sono presenti
    for (int i = 1; i <= chromosomeSize; ++i) {
        if (!visited[i]) {
            cerr << "Incomplete Chromosome!" << endl;
            return;
        }
    }
}

