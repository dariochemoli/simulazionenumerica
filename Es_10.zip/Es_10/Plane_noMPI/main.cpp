#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include <algorithm>
#include "random.h"
#include "chromosomes.h"
using namespace std;
 
 
int main () {


	// Inizializzo il generatore di numeri casuali
	Random rnd;
   
	int seed[4];  // Definisco un vettore 'seed' avente 4 elementi (per ora vuoto)
	int p1, p2;  // Definisco due numeri primi fra loro p1, p2
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	
	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// Estraggo i 34 punti casuali (città) nel piano
	
	
	// Vettore contenente le 34 coordinate delle città
	vector <vector <double>> C;
	
	
	// Genero 34 punti distribuiti casualmente in un piano all'interno di un quadrato di raggio 2, e i vettori che contengono le coordinate dei punti
	for (int i = 0; i < 34; i++) {
    	double x = rnd.Rannyu(-1.0, 1.0);
    	double y = rnd.Rannyu(-1.0, 1.0);
    
    	vector <double> v = {x, y};
    	C.push_back(v);
	}
	
	
	// Salvo su file i 34 punti casuali nel piano
	ofstream myfile;
	myfile.open("points_plane.dat");
	
	for (int i = 0; i < 34; i++) {
        myfile << C[i][0] << "\t" << C[i][1] << endl;
    }
    myfile.close();
    
    
     ////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // Implemento l'algoritmo genetico per risolvere il travelling salesman problem nel piano
    
    
    // Definisco un oggetto Chromosome e applico lo Shuffle a tutti
	Chromosomes cromo1;
	// Mischio i valori di tutti i cromosomi
	cromo1.ShuffleAll();
	// Implemento il vettore delle città (punti nel piano)
	cromo1.SetCities(C);
	
	int u, v, Q;
	double q, mlf;
	vector <vector <int>> newpop;  // Vettore in cui salvo i nuovi cromosomi di volta in volta
	vector <int> new1;
	vector <int> new2;
	ofstream min_loss, mean_loss;
	
	min_loss.open("min_loss_function_p.dat");
	mean_loss.open("mean_loss_function_p.dat");
	
	// Implemento un ciclo di 500 iterazioni dell'algoritmo genetico
	for (int i = 0; i < 500; i++) {
		// Ordino i cromosomi
		cromo1.Sort();
		
		// Salvo la loss function minima e la media delle loss function della i-esima generazione
		min_loss << i+1 << "\t" << cromo1.LossFunction(cromo1.GetNum() - 1) << endl;
		mlf = 0.0;
		
		for (int j = 0; j < cromo1.GetNum(); j++) {
			mlf += cromo1.LossFunction(j) / (double)(cromo1.GetNum());
		}
		mean_loss << i+1 << "\t" << mlf << endl;
		
		// Implemento un ciclo in modo tale da creare una nuova popolazione di GetNum individui
		for (int i = 0; i < cromo1.GetNum()/2; i++) {
			// Scelgo u,v in modo tale che è molto probabile che si scelgano i cromosomi migliori (con loss function bassa)
			u = int(pow(rnd.Rannyu(), 0.2) * cromo1.GetNum());
			v = int(pow(rnd.Rannyu(), 0.2) * cromo1.GetNum());
			q = rnd.Rannyu();
			Q = (int)(rnd.Rannyu(1, 5));
		
			// Mi assicuro che u e v non siano uguali fra loro
			if (u == v and v != 0) v -= 1;
			// else if (u == v and v == 0) v += 1;
		
			// Eseguo un crossover fra i due cromosomi con indici u,v con probabilità 0.75
			if (q < 0.75) {
				new1 = cromo1.Crossover(u, v)[0];
				new2 = cromo1.Crossover(u, v)[1];
			}
			else {
				new1 = cromo1.GetChromosome(u);
				new2 = cromo1.GetChromosome(v);
			}
		
			// Eseguo una mutazione sui cromosomi u,v con probabilità 0.2
			if (q < 0.2 and Q == 1) {
				new1 = cromo1.Mutation1(new1);
				new2 = cromo1.Mutation1(new2);
			}
			if (q < 0.2 and Q == 2) {
				new1 = cromo1.Mutation2(new1);
				new2 = cromo1.Mutation2(new2);
			}
			if (q < 0.2 and Q == 3) {
				new1 = cromo1.Mutation3(new1);
				new2 = cromo1.Mutation3(new2);
			}
			if (q < 0.2 and Q == 4) {
				new1 = cromo1.Mutation4(new1);
				new2 = cromo1.Mutation4(new2);
			}
			
			// Controllo la validità dei nuovi cromosomi
			cromo1.Check(new1);
			cromo1.Check(new2);
			
			// Aggiungo i due cromosomi soggetti eventualmente al crossover e alla mutazione alla nuova popolazione
			newpop.push_back(new1);
			newpop.push_back(new2);
			
		}
		cromo1.NewPopulation(newpop);
		newpop.clear();
	}
	min_loss.close();
	mean_loss.close();
	
	
	// Ordino ancora una volta i cromosomi e scelgo ora la soluzione al problema come quella codificata dall'ultimo cromosoma
 	cromo1.Sort();
 	
	int bestIndex = cromo1.GetNum() - 1;

	// Estraggo la sequenza di città dal cromosoma migliore
	vector <int> bestChromosome = cromo1.GetChromosome(bestIndex);
	
	// Estraggo ora l'ordine delle città
	vector <vector <double>> result_c = cromo1.GetCities(bestIndex);
	
	// Salvo il percorso ottimale in "result_plane.dat"
	myfile.open("result_plane.dat");

	for (int i = 0; i < cromo1.GetSize(); i++) {
		myfile << result_c[i][0] << "\t" << result_c[i][1] << endl;
	}
	myfile.close();
	
 	
 	////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	rnd.SaveSeed();
	return 0;
	
}