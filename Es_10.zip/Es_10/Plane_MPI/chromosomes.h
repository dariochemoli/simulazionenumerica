#ifndef CHROMOSOME_H
#define CHROMOSOME_H
#include <vector>
#include "random.h"
using namespace std;



class Chromosomes {
	

// Funzione che calcola la distanza euclidea
double dist(const vector<double>& v1, const vector<double>& v2) {
    double dx = v2[0] - v1[0];
    double dy = v2[1] - v1[1];
    return sqrt(dx*dx + dy*dy);
}



// Funzione che verifica se il termine 'element' sia presente nel vettore 'chromo'
bool in(const int element, vector <int> chromo) {
	for(unsigned int i=0; i < chromo.size(); i++) if(element == chromo.at(i)) return true;
  	return false;
}


private:
	 // Metodo usato dal costruttore per inizializzare i cromosomi
    void InitializeChromosomes();
    
    // Numero di cromosomi
    int numChromosomes;
    
    // Dimensione dei cromosomi
    int chromosomeSize;
    
    // Vettore in cui sono contenuti i cromosomi
    vector <vector <int> > chromosomes;
    
    // Vettore contenente i punti delle città
    vector <vector <double> > cities;
    
    // Oggetto Random per generare numeri casuali
    Random random;


public:
	// Costruttore
    Chromosomes();
    
    // Metodo che restituisce il singolo cromosoma index
    vector<int>& GetChromosome(int index);
    
    // Metodo che permuta in modo casuale i valori del cromosoma index
    void Shuffle(int index);
    
    // Metodo che applica il Shuffle a tutti i cromosomi
    void ShuffleAll();
    
    // Metodo che applica un crossover ai cromosomi index1 e index2
    vector <vector <int> > Crossover(int index1, int index2);
    
    // Metodo che stampa a schermo i valori del cromosoma index
    void PrintChromosome(int index);
    
    // Metodo che inizializza il vettore cities
    void SetCities(vector <vector <double> > c);
    
    // Metodo che accede al vettore delle città riferite al cromosoma index
    vector <vector <double> > GetCities(int index);
    
    // Metodi che implementano mutazioni sul cromosoma index
    vector <int> Mutation1(vector <int>& vec);
    vector <int> Mutation2(vector <int>& vec);
    vector <int> Mutation3(vector <int>& vec);
    vector <int> Mutation4(vector <int>& vec);
    
    // Metodo che calcola la Loss Function riferita al cromosoma index (linka i valori del cromosoma alle città contenute in 'cities')
    double LossFunction(int index);
    
    // Metodo che accede al numero di cromosomi
    int GetNum();
    
    // Metodo che accede alla dimensione dei cromosomi
    int GetSize();
    
    // Metodo per ordinare i cromosomi secondo la loro loss function tramite Bubble Sort
    void Sort();
    
    // Metodo per sostituire la popolazione
    void NewPopulation(vector <vector <int> >);
    
    // Metodo per sostituire un cromosoma
    void Substitute(vector <int> chromosome, int n);
    
    // Metodo per controllare se un cromosoma è valido
    void Check(vector <int> chromosome);
    
};

#endif // CHROMOSOME_H
