#include <iostream>
#include <fstream>
#include <ostream>
#include <cmath>
#include <iomanip>
#include "MD_MC.h"

using namespace std;

// MC: Liquido

int main() {
	 
	Input(); //Inizializzo il simulatore e il generatore e leggendo le osservabili iniziali da 'input.in'
	int nconf = 1;
	Equilibration();
	
  	for(int iblk=1; iblk <= nblk; iblk++) { // Faccio partire la simulazione ciclando sul numero di blocchi
		Reset(iblk);   // Resetto le osservabili , calcolandone di nuovo per ogni blocco
    
    	for(int istep=1; istep <= nstep; istep++) {  // Ciclo sul numero di passi della simulazione
      		Move();  // In questo caso implementa l'algoritmo di Verlet, che modifica le velocità e le posizioni delle particelle
      		Measure();  // Misura le osservabili del sistema (en. potenziale, en. cinetica, ecc.)
      		Accumulate(); // Sommo le osservabili calcolate passo dopo passo
      			
      		if(istep%10 == 0){
      			// ConfXYZ(nconf);//Write actual configuration in XYZ format //Commented to avoid "filesystem full"! 
        		nconf += 1;  // Se la riga sopra è commentata, questa variabile non è utile alla simulazione
      		}
    	}
		Averages(iblk);  // Salva in file esterni le medie progressive con gli errori delle osservabili termodinamiche
  	}
  	ConfFinal(); //Write final configuration

  	return 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void Input(void) {
	
	ifstream ReadInput, ReadConf, ReadVelocity, Primes, Seed;

	cout << "Classic Lennard-Jones fluid        " << endl;
	cout << "MD(NVE) / MC(NVT) simulation       " << endl << endl;
	cout << "Interatomic potential v(r) = 4 * [(1/r)^12 - (1/r)^6]" << endl << endl;
	cout << "Boltzmann weight exp(- beta * sum_{i<j} v(r_ij) ), beta = 1/T " << endl << endl;
	cout << "The program uses Lennard-Jones units " << endl;

	// Read seed for random numbers
	int p1, p2;
	Primes.open("Primes");
	Primes >> p1 >> p2 ;
	Primes.close();

	// Read input informations
	ReadInput.open("input.in");

	ReadInput >> iNVET;  // 0 = Molecular Dynamics, 1 = Monte-Carlo simulation
	ReadInput >> restart;  // 0 = No Restart, 1 = Restart

	if(restart) Seed.open("seed.out");  // Se facciamo funzionare il restart, per inizializzare il generatore utilizza i valori salvati in 'seed.out'
	else Seed.open("seed.in");
	Seed >> seed[0] >> seed[1] >> seed[2] >> seed[3];
	rnd.SetRandom(seed,p1,p2);
	Seed.close();
	
	// Leggo la temperatura da 'input.in'
	ReadInput >> temp;
	beta = 1.0/temp;
	cout << "Temperature = " << temp << endl;

	// Leggo il numero di particelle per blocco da 'input.in'
	ReadInput >> npart;
	cout << "Number of particles = " << npart << endl;

	// Leggo la densità da 'input.in'
	ReadInput >> rho;
	cout << "Density of particles = " << rho << endl;
	vol = (double)npart/rho;
	box = pow(vol,1.0/3.0);
	cout << "Volume of the simulation box = " << vol << endl;
	cout << "Edge of the simulation box = " << box << endl;

	// Leggo il raggio di cutoff da 'input.in'
	ReadInput >> rcut;
	cout << "Cutoff of the interatomic potential = " << rcut << endl << endl;
    
    // Leggo il passo temporale dt da 'input.in'
	ReadInput >> delta;

	// Leggo il numero di blocchi da 'input.in'
	ReadInput >> nblk;
	
	// Leggo il numero di step per ogni blocco da 'input.in'
	ReadInput >> nstep;

	cout << "The program perform Metropolis moves with uniform translations" << endl;
	cout << "Moves parameter = " << delta << endl;
	cout << "Number of blocks = " << nblk << endl;
	cout << "Number of steps in one block = " << nstep << endl << endl;
	ReadInput.close();

	// Definisco gli indici che determinano le osservabili
	iv = 0; //Potential energy
	iw = 1; //Pression
	n_props = 2; //Number of observables
	
	// Implemento g(r)
	igofr = 2;
  	nbins = 100;
  	n_props = n_props + nbins;
  	bin_size = (box/2.0)/(double)nbins;

	// Costruisco la configurazione iniziale
	cout << "Read initial configuration" << endl << endl;
	
	// Se utilizzo il restart, leggo le velocità che sono state salvate dall'ultima simulazione
	if(restart) {
    	ReadConf.open("config.out");
    	ReadVelocity.open("velocity.out");
    	
    	for (int i=0; i<npart; ++i) {ReadVelocity >> vx[i] >> vy[i] >> vz[i];}
	}
	
	// Se non implemento il restart, genero le velocità iniziali sulle tre coordinate di tutte le particelle nel singolo blocco
	else {
    	ReadConf.open("config.in");
    	cout << "Prepare velocities with center of mass velocity equal to zero " << endl;
    	double sumv[3] = {0.0, 0.0, 0.0};
    
    	for (int i=0; i<npart; ++i) {  // Ciclo su tutte le particelle del singolo blocco
			vx[i] = rnd.Gauss(0.0,sqrt(temp));  // Distribuzione delle velocità secondo Stefan-Boltzmann
      		vy[i] = rnd.Gauss(0.0,sqrt(temp));
      		vz[i] = rnd.Gauss(0.0,sqrt(temp));
      		sumv[0] += vx[i];
      		sumv[1] += vy[i];
      		sumv[2] += vz[i];
    	}
    	
		for (int idim=0; idim<3; ++idim) {sumv[idim] /= (double)npart;}
    	double sumv2 = 0.0, fs;
    
    	for (int i=0; i<npart; ++i) {
    		vx[i] = vx[i] - sumv[0];  // Sottraggo le velocità di drift
    		vy[i] = vy[i] - sumv[1];
    		vz[i] = vz[i] - sumv[2];
    		sumv2 += vx[i]*vx[i] + vy[i]*vy[i] + vz[i]*vz[i];
    	}
    	sumv2 /= (double)npart;
    	fs = sqrt(3 * temp / sumv2);   // fs = velocity scale factor 
    	cout << "velocity scale factor: " << fs << endl << endl;
    
    	for (int i=0; i<npart; ++i) {
    		vx[i] *= fs;  // Velocità sulle tre coordinate della singola particella
    		vy[i] *= fs;
    		vz[i] *= fs;
    	}
  	}

	// Leggo le coordinate delle 108 particelle in 'config.in'
	for (int i=0; i<npart; ++i) {
    	ReadConf >> x[i] >> y[i] >> z[i];
    	x[i] = Pbc( x[i] * box );  // Scalo le coordinate, in modo che tutte le particelle siano contenute nel blocco in modo ordinato
    	y[i] = Pbc( y[i] * box );
    	z[i] = Pbc( z[i] * box );
  	}
	ReadConf.close();  // Fine lettura di coordinate e velocità

	for (int i=0; i<npart; ++i) {
		
    	if(iNVET) {  // Caso algoritmo di Metropolis
    		xold[i] = x[i];
			yold[i] = y[i];
      		zold[i] = z[i];
    	}
    	else {  // Caso algoritmo di Verlet
    		xold[i] = Pbc(x[i] - vx[i] * delta);  // Salvo le coordinate della particella i-esima r_i(t - dt) utilizzando la velocità distribuita secondo Stefan-Boltzmann
      		yold[i] = Pbc(y[i] - vy[i] * delta);  // Così facendo so che l'algoritmo di Verlet è invariante per inversione temporale
      		zold[i] = Pbc(z[i] - vz[i] * delta);
    	}
  	}
  	
	// Tail corrections for potential energy and pressure
   	vtail = (8.0*pi*rho)/(9.0*pow(rcut,9)) - (8.0*pi*rho)/(3.0*pow(rcut,3));
   	ptail = (32.0*pi*rho)/(9.0*pow(rcut,9)) - (16.0*pi*rho)/(3.0*pow(rcut,3));
   
   cout << "Tail correction for the potential energy = " << vtail << endl;
   cout << "Tail correction for the virial           = " << ptail << endl;
  
	// Calcolo le osservabili di partenza
	Measure();

	// Stampo le osservabili di partenza
	cout << "Initial potential energy (with tail corrections) = " << walker[iv]/(double)npart + vtail << endl;
    cout << "Virial                   (with tail corrections) = " << walker[iw]/(double)npart + ptail << endl;
    cout << "Pressure                 (with tail corrections) = " << rho * temp + (walker[iw] + (double)npart * ptail) / vol << endl;
  	cout << "Initial temperature      = " << walker[it] << endl;
  	cout << "Initial kinetic energy   = " << walker[ik]/(double)npart << endl;
  	cout << "Initial total energy     = " << walker[ie]/(double)npart << endl;

	return;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Implemento un passo mediante algoritmo di Verlet o algoritmo di Metropolis
void Move() {
	int o;
  	double p, energy_old, energy_new;
  	double xnew, ynew, znew;

	// Caso metodo Monte-Carlo -> Algoritmo di Metropolis
	if(iNVET) {
  
		for(int i=0; i<npart; ++i) {
    		o = (int)(rnd.Rannyu()*npart);  // Seleziono una particella random

      		// Calcolo l'energia (potenziale) del sistema attuale tramite la funzione Boltzmann
      		energy_old = Boltzmann(x[o],y[o],z[o],o);

      		// Implemento uno spostamento random della particella
      		x[o] = Pbc( x[o] + delta*(rnd.Rannyu() - 0.5) );
      		y[o] = Pbc( y[o] + delta*(rnd.Rannyu() - 0.5) );
      		z[o] = Pbc( z[o] + delta*(rnd.Rannyu() - 0.5) );

	  		// Calcolo la nuova energia del sistema dopo lo spostamento della particella
      		energy_new = Boltzmann(x[o],y[o],z[o],o);  // Energia implementata in [274]

      		// Metropolis test
      		p = exp(beta*(energy_old-energy_new));
      	
      		if(p >= rnd.Rannyu()) {  // Se il Metropolis accetta il movimento, rimpiazzo le variabili di posizione vecchie con quelle nuove
        		xold[o] = x[o];
        		yold[o] = y[o];
        		zold[o] = z[o];
        		accepted++;
      		} 
      		else {
        		x[o] = xold[o];
        		y[o] = yold[o];
        		z[o] = zold[o];
      		}
      		attempted++;
		}
	}
	
	// Caso Molecular Dynamics -> Algoritmo di Verlet
	else {
		// Vettori delle tre componenti della forza totale agente sulle 108 particelle (m_part = 108)
    	double fx[m_part], fy[m_part], fz[m_part];
		// Valuto le forze sulla particella i-esima (la forza è valutata in [309])
    	for(int i=0; i<npart; ++i) {
      		fx[i] = Force(i,0);
      		fy[i] = Force(i,1);
      		fz[i] = Force(i,2);
    	}

		// Computo le nuove coordinate delle particelle utilizzando la forza
    	for(int i=0; i<npart; ++i) {

      		xnew = Pbc( 2.0 * x[i] - xold[i] + fx[i] * pow(delta,2) );
      		ynew = Pbc( 2.0 * y[i] - yold[i] + fy[i] * pow(delta,2) );
      		znew = Pbc( 2.0 * z[i] - zold[i] + fz[i] * pow(delta,2) );

      		vx[i] = Pbc(xnew - xold[i])/(2.0 * delta);
      		vy[i] = Pbc(ynew - yold[i])/(2.0 * delta);
      		vz[i] = Pbc(znew - zold[i])/(2.0 * delta);

      		xold[i] = x[i];
      		yold[i] = y[i];
      		zold[i] = z[i];

      		x[i] = xnew;
      		y[i] = ynew;
      		z[i] = znew;
      		
			// L'algoritmo di Verlet accetta tutte le mosse
      		accepted = accepted + 1.0;
      		attempted = attempted + 1.0;
    	}
	}
  return;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Calcolo il potenziale di LJ a cui una particella avente coordinate xx, yy, zz è soggetta
double Boltzmann(double xx, double yy, double zz, int ip) {
	double ene=0.0;
	double dx, dy, dz, dr;

  for (int i=0; i<npart; ++i)
  {
    if(i != ip)
    {
// distance ip-i in pbc
      dx = Pbc(xx - x[i]);
      dy = Pbc(yy - y[i]);
      dz = Pbc(zz - z[i]);

      dr = dx*dx + dy*dy + dz*dz;
      dr = sqrt(dr);

      if(dr < rcut)
      {
        ene += 1.0/pow(dr,12) - 1.0/pow(dr,6);
      }
    }
  }
  return 4.0*ene;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Computa la forza sulle particelle come l'opposto del gradiente del potenziale
double Force(int ip, int idir) {
	double f=0.0;
	double dvec[3], dr;

	for (int i=0; i<npart; ++i) {
		
    	if(i != ip) {
      		dvec[0] = Pbc( x[ip] - x[i] );  // distance ip-i in pbc
      		dvec[1] = Pbc( y[ip] - y[i] );
      		dvec[2] = Pbc( z[ip] - z[i] );

      		dr = dvec[0]*dvec[0] + dvec[1]*dvec[1] + dvec[2]*dvec[2];
      		dr = sqrt(dr);

      		if(dr < rcut) {
        		f += dvec[idir] * (48.0/pow(dr,14) - 24.0/pow(dr,8)); // -Grad_ip V(r)
      		}
		}
	}
  	return f;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void Measure() {
	// ofstream ist_Epot, ist_Pres;
	int bin;
	int couples = 0;
  	double v = 0.0;
  	double pr = 0.0;
  	double vij;
  	double dx, dy, dz, dr;
  	
  	// Resetto l'istogramma di' g(r)
  	for (int k=igofr; k<igofr+nbins; ++k) {walker[k]=0.0;}

	// Ciclo su tutte le coppie di particelle
	for (int i=0; i<npart-1; ++i) {
  		
		for (int j=i+1; j<npart; ++j) {
    		couples += 1;
    
			// (dx, dy, dz) è il vettore distanza fra una coppia di particelle
			dx = Pbc(x[i] - x[j]);
			dy = Pbc(y[i] - y[j]);
      		dz = Pbc(z[i] - z[j]);

      		dr = dx*dx + dy*dy + dz*dz;
      		dr = sqrt(dr);
      		
      		// Riempio l'istogramma di g(r)
     		bin = int(dr/bin_size);
     		if(bin < nbins) {walker[igofr + bin] += 2;}

	  		// Se la distanza fra due particelle è minore del raggio di cutoff, questa da un contributo all'energia potenziale di vij
      		if(dr < rcut) {
        		vij = 1.0/pow(dr,12) - 1.0/pow(dr,6);
        		v += vij;
        		pr += 48*(pow(dr, -12) - 1/2 * pow(dr, -6)) / (3*vol);
      		}
    	}          
	}
		
	// ist_Epot.open("solid_ist_epot.dat", ofstream::app);
	// ist_Pres.open("solid_ist_pres.dat", ofstream::app);

	// Da kin e da v possono essere misurate tutte le osservabili del sistema, contenute nel vettore walker
	walker[iv] = 4.0 * v; // Energia potenziale
	// ist_Epot << walker[iv] << endl;
  	walker[iw] = rho / beta + pr / couples;
  	// ist_Pres << walker[iw] << endl;
  	
  	// ist_Epot.close();
  	// ist_Pres.close();

	return;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Reset block averages
void Reset(int iblk) {
   
   if(iblk == 1)
   {
       for(int i=0; i<n_props; ++i)
       {
           glob_av[i] = 0;
           glob_av2[i] = 0;
       }
   }

   for(int i=0; i<n_props; ++i)
   {
     blk_av[i] = 0;
   }
   blk_norm = 0;
   attempted = 0;
   accepted = 0;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Sommo i valori delle osservabili che ho calcolato passo dopo passo nel vettore blk_av
void Accumulate(void) {

   for(int i=0; i<n_props; ++i)  // n_props sono il numero di osservabili
   {
     blk_av[i] = blk_av[i] + walker[i];  // Sommo i valori delle osservabili calcolate mediante Measure() in blk_av
   }
   blk_norm = blk_norm + 1.0;  // Conto quante volte ho valutato le osservabili
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


// Valuto e salvo le medie progressive e le dev standard progressive delle osservabili per il blocco iblk dopo un dato numero di passi
void Averages(int iblk) {
  // iblk indica lo i-esimo blocco su cui stiamo calcolando le osservabili
    
   // ofstream Epot, Ekin, Etot, Temp, Pres;
   ofstream Epot, Pres, G;
   const int wd=12;
   const int wd1=20;
    
    cout << "Block number " << iblk << endl;
    cout << "Acceptance rate " << accepted/attempted << endl << endl;
    
    Epot.open("output_epot.dat", ios::app);
    Pres.open("output_pres.dat", ios::app);
    G.open("output_g.dat", ios::app);
    
    stima_pot = blk_av[iv]/blk_norm/(double)npart + vtail;  // Energia potenziale per particella
    glob_av[iv] += stima_pot; 
    glob_av2[iv] += stima_pot*stima_pot;
    err_pot=Error(glob_av[iv],glob_av2[iv],iblk);
    
    stima_pres = blk_av[iw]/blk_norm + ptail * (double)npart;  // Pressione
    glob_av[iw] += stima_pres;
    glob_av2[iw] += stima_pres*stima_pres;
    err_press=Error(glob_av[iw],glob_av2[iw],iblk);

	//Potential energy per particle
    Epot << setw(wd) << iblk <<  setw(wd) << stima_pot << setw(wd) << glob_av[iv]/(double)iblk << setw(wd) << err_pot << endl;
    
	// Pressione
    Pres << setw(wd1) << iblk << setw(wd1) << setprecision(10) << stima_pres << setw(wd1) << setprecision(10) << glob_av[iw]/(double)iblk
    << setw(wd1) << setprecision(10) << err_press << endl;
    
    // g(r)
    for(int i=0; i<nbins; i++) {
      double r = bin_size*i;
      double r_dr = r + bin_size;
      blk_av[igofr+i] /= rho * npart * 4.*M_PI/3.*(r_dr*r_dr*r_dr - r*r*r);
      double gdir = blk_av[igofr + i] / blk_norm;
	  glob_av[igofr + i] += gdir;
      glob_av2[igofr + i] += gdir * gdir;
      err_gdir = Error(glob_av[igofr + i], glob_av2[igofr + i], iblk);
      // Gofr << setw(wd) << iblk << setw(wd) << r <<setw(wd) << glob_av[iv]/(double)iblk << setw(wd) << err_gdir << endl;
      if(iblk == nblk) {G << r << setw(wd) << glob_av[igofr + i]/double(nblk)<< setw(wd) << err_gdir << endl;}
    }

    cout << "----------------------------" << endl << endl;

	// Chiudo i file in cui vengono salvate le medie progressive delle osservabili
    Epot.close();
    Pres.close();
    G.close();
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void Equilibration() {
	ofstream Veq, Peq;
	// Veq.open("solid_u_eq.dat");
	// Peq.open("solid_p_eq.dat");
	cout << "The system is being balanced..." << endl;
	
	int steps = equilibration_steps;  // Variabile definita in MD_MC.h (in questo caso vale 1000)
	// double target_temp = temp;
    // double current_temp;
    // vector <double> vec_temp;  // Vettore delle temperature istantanee del sistema
    
	for (int i = 0; i < steps; i++) {  // Eseguo la fase di equilibrazione
    	Move();
    	// Measure();
        // current_temp = walker[it];  // Calcolo la temperatura istantanea del sistema
        // vec_temp.push_back(current_temp);
        // Veq << i << "\t" << walker[iv] << endl;
        // Peq << i << "\t" << walker[iw] << endl;
	}
      /*
        if (i % 500 == 0 and i != 0) {  // Riscalo le velocità dopo ogni 500 passi per raggiungere la temperatura target
        	double mean_temp = 0.0;
        	for (int k = vec_temp.size()-80; k < vec_temp.size(); k++) {
        		mean_temp += vec_temp[k] / 80;
        	}
        	double scale_factor = sqrt(target_temp / mean_temp);
        	
        	for (int j = 0; j < npart; j++) {
            	vx[j] *= scale_factor;
            	vy[j] *= scale_factor;
            	vz[j] *= scale_factor;
            	xold[j] = Pbc(x[j] - vx[j] * delta);
     			yold[j] = Pbc(y[j] - vy[j] * delta);
     			zold[j] = Pbc(z[j] - vz[j] * delta);
        	}
        }
    }
    for (int i = 0; i < 500; i++) {  // Dopo gli equilibration_steps faccio evolvere ancora per 500 step senz ariscalamenti
    	Move();
    	Measure();
    	Veq << equilibration_steps+i+1 << "\t" << walker[iv] << endl;
    	Peq << equilibration_steps+i+1 << "\t" << walker[iv] << endl;
    }
    */
    // Veq.close();
    // Peq.close();
    cout << "Equilibration complete" << endl;
    cout << "---------------------------" << endl << endl;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void ConfFinal(void)
{
  ofstream WriteConf, WriteVelocity, WriteSeed;

  cout << "Print final configuration to file config.out" << endl << endl;
  WriteConf.open("config.out");
  WriteVelocity.open("velocity.out");
  for (int i=0; i<npart; ++i)
  {
    WriteConf << x[i]/box << "   " <<  y[i]/box << "   " << z[i]/box << endl;
    WriteVelocity << vx[i] << "   " <<  vy[i] << "   " << vz[i] << endl;
  }
  WriteConf.close();
  WriteVelocity.close();

  rnd.SaveSeed();
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


void ConfXYZ(int nconf){ //Write configuration in .xyz format
  ofstream WriteXYZ;

  WriteXYZ.open("frames/config_" + to_string(nconf) + ".xyz");
  WriteXYZ << npart << endl;
  WriteXYZ << "This is only a comment!" << endl;
  for (int i=0; i<npart; ++i){
    WriteXYZ << "LJ  " << Pbc(x[i]) << "   " <<  Pbc(y[i]) << "   " << Pbc(z[i]) << endl;
  }
  WriteXYZ.close();
}

double Pbc(double r)  //Algorithm for periodic boundary conditions with side L=box
{
    return r - box * rint(r/box);
}

double Error(double sum, double sum2, int iblk)
{
    return sqrt(fabs(sum2/(double)iblk - pow(sum/(double)iblk,2))/(double)iblk);
}
