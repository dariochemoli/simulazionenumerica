#include <iostream>
#include <fstream>
#include <string>
#include <cmath>
#include <vector>
#include <algorithm>
#include "random.h"

using namespace std;


double dev_st(const vector <double> v1, const vector <double> v2, int n) {
	
	if (n == 0) {
		return 0;
	}
	else {
		return sqrt((v2[n] - pow(v1[n], 2)) / n);
	}
}


 
int main (/*int argc, char *argv[]*/) {

	// Inizializzo il generatore di numeri casuali fornendogli i quattro interi per generare il seed
	Random rnd;
   
	int seed[4];  // Definisco un vettore 'seed' avente 4 elementi (per ora vuoto)
	int p1, p2;  // Definisco due numeri primi fra loro p1, p2
	
	ifstream Primes("Primes");
	if (Primes.is_open()) {
    	Primes >> p1 >> p2 ;  // Pongo p1, p2 come i primi due elementi di Primes
	} else cerr << "PROBLEM: Unable to open Primes" << endl;
	Primes.close();

	ifstream input("seed.in");
	string property;
	if (input.is_open()){
    	while ( !input.eof() ){
        	input >> property;
        if( property == "RANDOMSEED" ){
        	input >> seed[0] >> seed[1] >> seed[2] >> seed[3];  //Riempio il vettore 'seed' con i primi quattro valori di 'seed.in'
        	rnd.SetRandom(seed,p1,p2);  // Inizializzo il seed del generatore con i valori di 'seed' e p1, p2
         }
      }
      input.close();
	} else cerr << "PROBLEM: Unable to open seed.in" << endl;
	
	
	
	// Parametri utili
	int M = 100000;  // Numeri casuali generati in totale
	int L = 1000;  // Valori all'interno di un blocco
	int N = M/L;  // Numero di blocchi
	double sum_C;
	double sum_P;
	double T = 1.0;
	double K = 100.0;  // Prezzo di esercizio
	double r = 0.1;  // Tasso di crescita (uguale al tasso di crescita?)
	double sigma = 0.25;  // Volatilità
	double S_0 = 100.0;
	
	// vector <double> S(N);  // Array in cui immagazzino il final asset prize 100 volte, per poi calcolare la media a blocchi di C e P
	vector <double> C(N);
	vector <double> C2(N);
	vector <double> P(N);
	vector <double> P2(N);
	vector <double> sum_prog_C(N);
	vector <double> sum_prog_P(N);
	vector <double> sum_prog_C2(N);
	vector <double> sum_prog_P2(N);
	vector <double> error_C(N);
	vector <double> error_P(N);
	
	
	// Calcolo la media del prezzo dell'attività, dell'opzione Call europea, e dell'opzione Put europea per N blocchi
	for (int i = 0; i < N; i++) {
		//sum_s = 0.0;
		sum_C = 0.0;
		sum_P = 0.0;
		
		for (int j = 0; j < L; j++) {  // Computo L asset prices diversi, calcolo C e P di volta in volta e faccio N medie
			double S = S_0 * exp((r - pow(sigma, 2)/2) * T + sigma * rnd.Gauss(0, T));
			sum_C += exp(-r*T) * max(0.0, S - K);
			sum_P += exp(-r*T) * max(0.0, K - S);
		}
		C[i] = sum_C / L;
		C2[i] = pow(C[i], 2);
		P[i] = sum_P / L;
		P2[i] = pow(P[i], 2);
	}
	
	
	// Calcolo la media progressiva e la corrispondente deviazione standard di C e P
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_C[i] += C[j];
			sum_prog_C2[i] += C2[j];
			sum_prog_P[i] += P[j];
			sum_prog_P2[i] += P2[j];
		}
		sum_prog_C[i] /= (i+1);
		sum_prog_C2[i] /= (i+1);
		sum_prog_P[i] /= (i+1);
		sum_prog_P2[i] /= (i+1);
		error_C[i] = dev_st(sum_prog_C, sum_prog_C2, i);
		error_P[i] = dev_st(sum_prog_P, sum_prog_P2, i);
	}
	
	
	
	// Salvo i risultati ottenuti in 'results_2.dat'
	ofstream myfile;
	myfile.open("results_1.dat");
	
	for (int i = 0; i < 100; i++) {
        myfile << i+1 << "\t" << sum_prog_C[i] << "\t" << error_C[i] << "\t" << sum_prog_P[i] << "\t" << error_P[i] << endl;
    }
    
    myfile.close();
    
    
    /////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	// Resetto i vettori utilizzati precedentemente cosicchè utilizzare lo stesso procedimento per la stima di C(T) e P(T)
	C.assign(N, 0.0);
	C2.assign(N, 0.0);
	P.assign(N, 0.0);
	P2.assign(N, 0.0);
	sum_prog_C.assign(N, 0.0);
	sum_prog_P.assign(N, 0.0);
	sum_prog_C2.assign(N, 0.0);
	sum_prog_P2.assign(N, 0.0);
	error_C.assign(N, 0.0);
	error_P.assign(N, 0.0);
	
	double S = S_0;  // Condizione iniziale S(0) = 100
	
	
	// Calcolo iterativamente l'asset price S per poi valutare la media blocchi di C e P come in precedenza
	for (int i = 0; i < N; i++) {
		sum_C = 0.0;
		sum_P = 0.0;
		
		for (int j = 0; j < L; j++) {
			
			for (int k = 1; k <= 100; k++) {  // Ciclo in cui calcolo l'asset price
				S *= exp((r - pow(sigma, 2)/2) * (1.0/100.0) + sigma * sqrt(1.0/100.0) * rnd.Gauss(0, T));  // t(i+1) - t(i) = 1/100
			}
			sum_C += exp(-r*T) * max(0.0, S - K);  // Faccio N medie su questi C,P calcolati tutti da diverse estrapolazioni di S
			sum_P += exp(-r*T) * max(0.0, K - S);
			S = S_0;
		}
		C[i] = sum_C / L;
		C2[i] = pow(C[i], 2);
		P[i] = sum_P / L;
		P2[i] = pow(P[i], 2);
	}
	
	
	// Calcolo la media progressiva e la corrispondente deviazione standard di C e P
	for (int i = 0; i < N; i++) {
		
		for (int j = 0; j < i+1; j++) {
			sum_prog_C[i] += C[j];
			sum_prog_C2[i] += C2[j];
			sum_prog_P[i] += P[j];
			sum_prog_P2[i] += P2[j];
		}
		sum_prog_C[i] /= (i+1);
		sum_prog_C2[i] /= (i+1);
		sum_prog_P[i] /= (i+1);
		sum_prog_P2[i] /= (i+1);
		error_C[i] = dev_st(sum_prog_C, sum_prog_C2, i);
		error_P[i] = dev_st(sum_prog_P, sum_prog_P2, i);
	}
	
	
	// Salvo i risultati ottenuti in 'results_2.dat'
	myfile.open("results_2.dat");
	
	for (int i = 0; i < 100; i++) {
        myfile << i+1 << "\t" << sum_prog_C[i] << "\t" << error_C[i] << "\t" << sum_prog_P[i] << "\t" << error_P[i] << endl;
    }
    
    myfile.close();
	
	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	
	
	rnd.SaveSeed();
	return 0;
	
}